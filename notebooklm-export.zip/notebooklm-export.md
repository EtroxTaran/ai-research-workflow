# Produkt-Vision: AI Research Pipeline

**Projekt:** research-workflow-n8n
**Version:** 3.0 (finale Architektur)
**Datum:** 2026-04-06
**Status:** BEREIT FÜR IMPLEMENTIERUNG

---

## 1. Vision & Purpose

> Eine n8n-basierte Research-Pipeline, die über OpenClaw, Portal oder Telegram angesteuert wird, Recherchen parallel über 6-7 Datenquellen durchführt, mit adaptiven Quality Gates verifiziert, und die Ergebnisse über einen dedizierten Telegram Bot zuliefert — während eine wachsende Quellen-Datenbank die Qualität über Zeit steigert.

### Was es ist
- Ein **n8n-Workflow-System** auf dem B-Link R2D2 Server (Self-Hosted, lokal, 24/7)
- **CLI-first**: Gemini CLI, Claude CLI, Codex CLI statt direkte API-Calls wo möglich
- Ein **Nexus Portal Plugin** (`@nexus/plugin-research`) für Web-basiertes Management
- Ein **OpenClaw Skill** (`research-workflow`) für Nathan-Integration
- Ein **Unified Source System** (ein Namespace) das über Zeit Reputation aufbaut
- **Adaptive Pipeline**: Quick (<2min) / Standard (5-15min) / Deep (15-30min)

### Was es NICHT ist
- Kein Ersatz für OpenClaw — Nathan bleibt Orchestrator, n8n ist Worker
- Kein Real-Time-Chat — asynchroner Batch-Prozess mit Notification
- Kein eigenständiges Produkt — eingebettet ins bestehende Ökosystem

### Warum n8n statt OpenClaw-native?
| Problem (Spock in OpenClaw) | Lösung (n8n) |
|---|---|
| Sequentielle Ausführung | 6-7 Search-Branches parallel |
| Session-Timeouts → Kontextverlust | Persistente Workflows |
| Jeder Run kostet Sonnet/Opus-Tokens | CLI-basiert (Subscriptions/Free Tiers) |
| Cron-Jobs mit Fehler-History (42 broken) | Zuverlässige Schedule Triggers |
| Kein Audit-Trail | Execution History automatisch |
| Kein strukturierter HITL | Telegram Inline Buttons |

### Warum CLI-first statt direkte APIs?
| API-Ansatz | CLI-Ansatz |
|---|---|
| Pay-per-Token für jede LLM-Nutzung | Subscriptions/Free Tiers der CLIs |
| Eigenes Auth-Management pro Provider | CLI-Auth bereits lokal konfiguriert |
| HTTP Request Nodes + Error Handling | Execute Command Node, einheitlich |
| 5+ API-Keys managen | CLIs nutzen bestehende Sessions |

---

## 2. System-Architektur

```
┌─────────────────────────────────────────────────────────────────────┐
│                          TRIGGER LAYER                               │
│                                                                       │
│  Nico ──→ Nathan (OpenClaw) ──→ Skill: research-workflow ──┐        │
│  Portal ──→ "Neue Recherche" Button ───────────────────────┤        │
│  Schedule ──→ Weekly Digest / Monitoring ──────────────────┤        │
│  Research Bot ──→ Telegram Direct Message ─────────────────┘        │
└──────────────────────────────────┬──────────────────────────────────┘
                                   │ POST /webhook/research-start
                                   ▼
┌─────────────────────────────────────────────────────────────────────┐
│              n8n RESEARCH WORKFLOW (B-Link R2D2, lokal)              │
│                                                                       │
│  Phase 0 (Plan + Modus-Klassifizierung) → Quick/Standard/Deep       │
│  Phase 1 (6-7 Branches parallel) → Gate 1 (Standard/Deep)          │
│  Phase 2 (Counter-Research) → Gate 2 (nur Deep)                     │
│  Phase 3 (CoVe + FActScore + Judge) → Gate 3 (Standard/Deep)       │
│  Phase 4 (Synthesis) → Quality Gate → Deliver / HITL / Retry        │
└──────────────┬──────────────────────────────┬───────────────────────┘
               │                              │
               ▼                              ▼
┌──────────────────────────┐    ┌────────────────────────────────────┐
│   SurrealDB (Unified)    │    │   DELIVERY                          │
│   research/workflow      │    │   Research Bot → Telegram (Reports) │
│   (Runs, Reports,        │    │   Google Drive → Archiv             │
│    Sources, Creators,    │    │   SurrealDB → Portal Live-Status    │
│    Claims — MASTER)      │    └────────────────────────────────────┘
│                          │
│   openclaw/knowledge     │
│   (← Edge-Referenz auf   │
│    verified Claims ≥T2)  │
└──────────────────────────┘
```

### Zwei-Bot-Architektur
| Bot | System | Zweck |
|---|---|---|
| **Nathan Bot** (ID: 8213463852) | OpenClaw | Konversation mit Nico — Chat, Fragen, Delegation |
| **Research Bot** (Token: konfiguriert) | n8n | Research-Reports, HITL-Buttons, Status-Updates |

Kein Polling-Konflikt: Jeder Bot wird von genau einem System gepollt.

### Unified Source System (SurrealDB)
| Namespace | Rolle | Inhalt |
|---|---|---|
| `research/workflow` | **Master** | research_run, research_report, source_registry, creator, research_claim, used_source |
| `openclaw/knowledge` | **Referenz** | Verified Claims (≥T2) werden per Edge-Referenz verlinkt, nicht dupliziert |

**Prinzip:** Ein Source-System, eine Wahrheit. `openclaw/knowledge` referenziert `research/workflow.source_registry` per ID — kein Duplikat, kein Sync-Konflikt.

---

## 3. Research-Prozess — 5 Phasen (Adaptiv)

### Adaptive Pipeline-Tiefe

Phase 0 klassifiziert jede Query automatisch. User kann Modus überschreiben: `"Recherchiere [deep]: Beste GraphDB"`

| Modus | Auslöser | Branches | Gates | CLIs/LLMs | Kosten | Dauer |
|-------|----------|----------|-------|-----------|--------|-------|
| **Quick** | Einfache Fakten, kurze Fragen | KB + Web + Gemini Grounding | Nur Gate 4 | Gemini CLI | ~$0.02 | <2 min |
| **Standard** | Vergleiche, Analysen | Alle 6 Branches | Gate 1 + 3 + 4 | Gemini CLI + Codex CLI | ~$0.30-0.80 | 5-15 min |
| **Deep** | Investitionen, Tech-Evaluierungen | Alle 7 Branches + Counter + Full Verify | Alle 4 Gates + HITL | Alle CLIs + Grok API | ~$1-3 | 15-30 min |

### Phase 0 — PRISMA Setup & DAG Planning + Modus-Klassifizierung

| | |
|---|---|
| **Input** | Research Query (natürliche Sprache) + optionaler Kontext + optionaler Modus-Override |
| **Output** | Strukturierter Search Plan (JSON: Sub-Fragen, Suchbegriffe DE+EN, Source-Typen, Scope) + **Modus (Quick/Standard/Deep)** |
| **CLI** | Codex CLI (`codex exec`) |
| **Gate 0** | Search Plan vorhanden, ≥3 Quellen-Typen definiert, Sprache erkannt, Modus klassifiziert |
| **n8n Workflow** | `research-phase0-plan` |

Enthält: Query-Analyse, Domain-Klassifikation (`tech|finance|academic|product_comparison|travel|general`), Sprach-Erkennung (DE/EN), Komplexitäts-Klassifizierung, KB-Existenz-Check.

### Phase 1 — Parallele Datensammlung

6-7 Search-Branches laufen parallel in n8n (je nach Modus):

| Branch | Tool | CLI/API | Sprint | Modus |
|---|---|---|---|---|
| A: KB Search | SurrealDB (`kb-search.py`) | Execute Command | 1 | Alle |
| B: Web Search | Brave + Tavily (parallel) | HTTP Request | 1 | Alle |
| C: Deep Research | Gemini CLI mit Google Search Grounding | Execute Command | 2 | Standard + Deep |
| D: Social/Real-Time | Grok 4 API DeepSearch | HTTP Request | 2 | Standard + Deep |
| E: Academic | Semantic Scholar + ArXiv | HTTP Request | 3 | Standard + Deep |
| F: MiniFlux RSS | MiniFlux REST API | HTTP Request | 1 | Alle |
| G: Deep Research (optional) | You.com Research API | HTTP Request | 3 | Nur Deep |

**YouTube** wird über Gemini CLI (Branch C) oder `yt-transcript.py` abgedeckt.

| | |
|---|---|
| **Output** | Gesammelte Quellen + extrahierte Claims (strukturiertes JSON) |
| **Gate 1** | Quick: —, Standard: ≥8 Quellen ≥2 Plattformen, Deep: ≥12 Quellen ≥3 Plattformen ≥5 T1/T2 |
| **n8n Workflow** | `research-phase1-gather` + Sub-Workflows pro Branch |

### Phase 2 — Gegenrecherche + Devil's Advocate (Standard/Deep)

| | |
|---|---|
| **Input** | Claims aus Phase 1 |
| **Output** | Counter-Evidence, Devil's Advocate Argumente, Widersprüche-Tabelle |
| **CLI** | Claude CLI mit Opus (`claude -p --model opus`) für Devil's Advocate + Pre-Mortem |
| **Gate 2** | ≥80% Kernaussagen haben Counter-Research, Widersprüche dokumentiert |
| **n8n Workflow** | `research-phase2-counter` |
| **Sprint** | 2 |
| **Modus** | Nur Standard (light) + Deep (full) |

### Phase 3 — Claim-Level Verification (Standard/Deep)

Drei Methoden, kombiniert (Standard: nur CoVe, Deep: alle drei):

| Methode | Beschreibung | Tool | Modus |
|---|---|---|---|
| **CoVe** (Chain-of-Verification) | Claims isoliert verifizieren, Konsistenz prüfen | `research-quality-gate.py --cove` | Standard + Deep |
| **FActScore** | Atomare Aussagen gegen Web-Suche prüfen | `research-quality-gate.py --factscore` | Nur Deep |
| **LLM-as-Judge** | Cross-Model-Bewertung (5 Dimensionen, Score 1-5) | Gemini CLI (Cross-Model) | Standard + Deep |

| | |
|---|---|
| **Output** | Verification Table (Status pro Claim: VERIFIED / PARTIALLY / REFUTED) |
| **Gate 3** | Standard: ≥70% verified, Deep: ≥80% verified + Judge-Score ≥3.5 |
| **n8n Workflows** | `research-verify-cove`, `research-verify-factscore`, `research-judge` |
| **Sprint** | 2 (CoVe + Judge), 3 (FActScore) |

### Phase 4 — Freshness + Synthese + Quality Gate

| | |
|---|---|
| **Input** | Verified Claims + Quellen + Counter-Evidence + Verification Table |
| **Output** | Finaler Research Report (Markdown, Template v3) |
| **CLI** | Claude CLI mit Opus (Deep) oder Gemini CLI (Quick/Standard) |
| **Sprache** | Automatisch: DE Query → DE Report, EN Query → EN Report |
| **n8n Workflow** | `research-phase4-synthesize` |

**Quality Gate Entscheidung:**
```
IF gate == PASS AND confidence ≥ 75%  → Deliver
IF gate == PASS AND confidence < 75%  → Deliver mit HITL Approval Request
IF gate == FAIL AND retries < 3       → Replan (schwächste Phase wiederholen)
IF gate == FAIL AND retries ≥ 3       → HITL Escalation
```

---

## 4. n8n Sub-Workflows

| Workflow | Funktion | Sprint |
|---|---|---|
| `research-orchestrator` | Main: Trigger → Phasen → Gates → Delivery | 1 |
| `research-phase0-plan` | Query → Search Plan + Domain + Sprache | 1 |
| `research-phase1-gather` | Parallel-Dispatch + Merge + Dedup + Gate 1 | 1 |
| `research-search-kb` | SurrealDB Hybrid-Search | 1 |
| `research-search-web` | Brave + Tavily (parallel) | 1 |
| `research-search-miniflux` | MiniFlux REST API | 1 |
| `research-search-deep` | Gemini CLI (Search Grounding) | 2 |
| `research-search-social` | Grok 4 API DeepSearch | 2 |
| `research-search-academic` | Semantic Scholar + ArXiv | 3 |
| `research-search-youcom` | You.com Research API (optional, Deep) | 3 |
| `research-phase2-counter` | Devil's Advocate + Counter-Search | 2 |
| `research-phase3-verify` | CoVe + FActScore + Judge Orchestrierung | 2 |
| `research-phase4-synthesize` | Freshness + Report Template v3 | 1 |
| `research-deliver` | Research Bot + Drive + SurrealDB + KB-Sync | 1 |
| `research-hitl` | Telegram Inline Buttons + Approval | 2 |

Detaillierte Node-Specs: [`docs/n8n-workflow-specs.md`](./docs/n8n-workflow-specs.md)

---

## 5. CLI-first Strategie

### Verfügbare CLIs (auf B-Link R2D2)

| CLI | Version | Auth | Nutzung |
|---|---|---|---|
| `gemini` | v0.32.1 | Google API Key | Deep Research (Search Grounding), Synthesis, Judge |
| `claude` | v2.1.92 | Anthropic Key | Counter-Research (Opus), Synthesis (Deep) |
| `codex` | v0.112.0 | OpenAI Key | Planning, Query Decomposition, Web Analysis |

### Phasen-Zuordnung

| Phase | CLI/Tool | Begründung |
|---|---|---|
| Phase 0 (Planning) | Codex CLI | Schnell, guter Structured Output |
| Phase 1 (Deep Research) | Gemini CLI (Search Grounding) | Google-Index, 5K free/Mo, ersetzt Perplexity |
| Phase 1 (Social) | Grok 4 API | Native X/Twitter-Zugang, kein CLI verfügbar |
| Phase 1 (Web Search) | Brave + Tavily APIs | HTTP Request Nodes (kein CLI nötig) |
| Phase 2 (Devil's Advocate) | Claude CLI (Opus) | Stärkstes adversariales Reasoning |
| Phase 3 (CoVe + FActScore) | `research-quality-gate.py` | Bestehendes Script, kein LLM nötig |
| Phase 3 (Judge) | Gemini CLI | Cross-Model-Validation (anderer Provider!) |
| Phase 4 (Quick/Standard) | Gemini CLI | Kosteneffizient für Standard-Reports |
| Phase 4 (Deep) | Claude CLI (Opus) | Höchste Qualität für Investitionsentscheidungen |
| Quality Gate Scripts | Python (kein LLM) | Deterministische Strukturchecks |

### CLI-Aufrufe in n8n (Execute Command Nodes)

```bash
# Phase 0: Query Decomposition
codex exec "Zerlege diese Forschungsfrage in Sub-Fragen und klassifiziere den Modus: ${query}"

# Phase 1: Deep Research mit Google Grounding
gemini -p "Recherchiere umfassend mit Web-Quellen: ${query}. Gib alle Quellen-URLs an."

# Phase 2: Devil's Advocate
claude -p "Du bist ein kritischer Analyst. Finde die 5 stärksten Gegenargumente: ${claims}" --model opus

# Phase 3: Cross-Model Judge
gemini -p "Bewerte diesen Research-Report auf 5 Dimensionen (1-5): ${report}"

# Phase 4: Synthesis
claude -p "Erstelle einen Research-Report nach Template v3: ${verified_claims}" --model opus
```

**Prinzip:** CLI-first (Subscriptions/Free Tiers), API nur wo kein CLI vorhanden (Grok, Brave, Tavily). Cross-Model für Verification.

---

## 6. Such-Tools & Datenquellen

### Kosten-Übersicht (~$5-20/Monat)

| Tool | Typ | Kosten/Monat | Integration | Sprint |
|---|---|---|---|---|
| **Brave Search** | Web | $5 Credit (1K free) | HTTP Request | 1 |
| **Tavily Search + Extract** | Web | $0 Free Tier (1K/Mo) | HTTP Request | 1 |
| **Gemini CLI + Search Grounding** | Deep Research | $0 (5K free/Mo) | Execute Command | 2 |
| **Grok 4 API DeepSearch** | Social/X | ~$5-15 (usage) | HTTP Request | 2 |
| **You.com Research API** | Deep Research | $0 ($100 Credit ≈ 15 Mo) | HTTP Request | 3 |
| **Semantic Scholar** | Academic | $0 (kostenlos) | HTTP Request | 3 |
| **ArXiv** | Academic | $0 (kostenlos) | HTTP Request | 3 |
| **MiniFlux RSS** | News/RSS | $0 (Self-Hosted) | HTTP Request | 1 |
| **SurrealDB KB** | Knowledge Base | $0 (Self-Hosted) | Execute Command | 1 |

### Spätere Erweiterung
| Tool | Typ | Mehrwert |
|---|---|---|
| Exa | Semantic Neural Search | Discovery-Queries (1K free/Mo) |
| Firecrawl | Full-Page Extraction | Wenn Tavily Extract nicht reicht |
| OpenAlex + CrossRef | Academic | Breitere Abdeckung, Citation Verification |

---

## 7. Qualifiziertes Quellen-System

### Reputation Lifecycle

```
ENTDECKUNG                          BEWERTUNG                      REPUTATION                    NUTZUNG
├── Research findet Quelle          ├── Gate 1: Credibility       ├── Score berechnen:          ├── Trusted Sources priorisiert
│   → source_registry               │   Scoring                   │   (correct+1)/              │   in Phase 1
│   (T3, reputation: 0.5)          ├── Gates 2-4: Claims          │   (correct+incorrect+2)     ├── Gewichtung in Synthese
├── MiniFlux-Feed                   │   überleben → correct++     ├── >0.8 nach 3+ Runs:       └── Portal: Filter/Sort
│   → Auto-T2, reputation: 0.7    └── Claims fallen              │   Auto-Vorschlag Trusted        nach Reputation
├── Creator-Registry                    durch → incorrect++        └── <0.3: Auto-Downgrade
│   → trust per creator
└── Portal: Manuell
```

### Source Registry
Alle jemals gefundenen Quellen mit URL, Domain, Trust Level, Reputation Score, Correct/Incorrect Counts, Tags. Portal-UI zum Verwalten (Trust ändern, blockieren, Tags editieren).

### Creator Registry
Kuratierte Content Creators über alle Plattformen: YouTube, X, LinkedIn, Substack, Reddit, Blog, RSS, Podcast. Pro Creator: Name, Platform, Channel URL, Trust Level (high/medium/watch), Domain Tags, Active-Status. Auto-Discovery Queue mit HITL-Approval.

---

## 8. SurrealDB Schema

**Namespace:** `research/workflow`
**Schema-Datei:** [`schema/research-workflow.surql`](./schema/research-workflow.surql)

| Tabelle | Beschreibung |
|---|---|
| `research_run` | Research-Runs mit Status, Scores, Kosten, Manifest |
| `research_report` | Reports (Markdown, Quality Score, User Rating, NotebookLM ID) |
| `source_registry` | Quellen-Registry mit Reputation-Tracking |
| `creator` | Content Creator Registry (Multi-Platform) |
| `used_source` | Quellen-pro-Run Verknüpfung (Edge-Table) |
| `research_claim` | Claims mit Verification-Status (CoVe, FActScore, Judge) |

---

## 9. Web UI — Nexus Portal Plugin

**Plugin:** `@nexus/plugin-research` im Nexus Portal (`~/projects/ai-portal/`)
**Spezifikation:** [`portal/PLUGIN-SPEC.md`](./portal/PLUGIN-SPEC.md)

| Screen | Route | Sprint |
|---|---|---|
| Research Dashboard | `/research` | 1 |
| Report Viewer | `/research/runs/:runId` | 1 |
| Source Registry | `/research/sources` | 2 |
| Creator Registry | `/research/creators` | 2 |
| Neue Recherche | `/research/new` | 2 |

**Integration:** Portal triggert n8n via Webhook, pollt SurrealDB für Live-Status (TanStack Query, 5s Intervall während Run aktiv).

---

## 10. Delivery & HITL

### Delivery-Kanäle
| Kanal | Format | Wann |
|---|---|---|
| Research Bot (Telegram) | Report-Summary + Markdown | Immer |
| Google Drive | Markdown + optional PDF | Immer |
| SurrealDB | Strukturierte Daten (Run, Report, Claims, Sources) | Immer |
| openclaw/knowledge | Verified Claims (≥T2) | Bei PASS |

### HITL-Trigger
| Situation | Aktion | Kanal |
|---|---|---|
| Confidence < 60% nach Verification | Approval Request mit Preview | Research Bot: Inline Buttons |
| High-Stakes Domain (Finanzen, Recht, Medizin) | Mandatory Review | Research Bot: Inline Buttons |
| ≥30% Claims NICHT VERIFIZIERT | Report + Failure-Details | Research Bot |
| Quality Gate FAIL nach 3 Retries | Escalation mit Diagnose | Research Bot |
| Widersprüche ohne Auflösung | Entscheidungsvorlage | Research Bot: Inline Buttons |

**Buttons:** `[✅ Approve]` `[❌ Reject]` `[✏️ Edit Query]` — Timeout: 24h → Auto-Reject.

---

## 11. Spezial-Modi (Sprint 4)

### Weekly Digest (Multi-Domain)
Schedule: **Sonntag 08:00** → Für jeden konfigurierten Domain-Kanal:
1. MiniFlux: Ungelesene Entries der Woche filtern nach Domain
2. Creator Monitor: Neue Inhalte der Woche von tracked Creators
3. KB: Neue Claims der Woche aggregieren
4. Gemini CLI: Zusammenfassung der wichtigsten Entwicklungen
5. Research Bot → Telegram: Domain-Digest

**Konfigurierbare Kanäle** (in SurrealDB):
- **Tech/AI**: AI-News, Framework-Releases, Tool-Updates
- **Finanzen**: Marktentwicklungen, Portfoliorelevantes
- **Branchen-News**: Konfigurierbar pro Interesse

### Produktvergleich
Trigger: "X vs Y" / "bestes Z für [Zweck]" → Kriterien-Matrix → Pro-Kandidat-Suche + Head-to-Head → Negative Reviews → Vergleichstabelle + Entscheidungsmatrix.

### Continuous Monitoring
Schedule: Täglich/6h für definierte Topics → Delta-Only (nur Neues seit letztem Run) → Novelty-Score > 0.7 → Notification. Akkumuliert in SurrealDB.

### Domain-Routing
Phase 0 klassifiziert den Query und passt an: Source-Gewichtung, Creator-Filter, MiniFlux-Kategorien, Verification-Strenge (Finance/Medical = mandatory HITL).

---

## 12. NotebookLM Integration

| Phase | Feature | Sprint |
|---|---|---|
| 1 | Export: Optimiertes Markdown + Verified Sources als Paket | 4 |
| 2 | Direkte API: Apify NotebookLM Actor, Auto-Notebook-Erstellung | 5 |
| 3 | Bidirektional: NotebookLM-Insights zurück in KB | Später |

---

## 13. OpenClaw Integration

### Skill: `research-workflow`
| | |
|---|---|
| **Pfad** | `~/.openclaw/skills/research-workflow/SKILL.md` |
| **Trigger** | "recherchiere", "research", "untersuche", "analysiere [Topic]" |
| **Aktion** | HTTP POST → `localhost:5678/webhook/research-start` (B-Link n8n) |
| **Body** | `{query, domain_hint, language, trigger_source: "openclaw"}` |
| **Antwort** | "Research-Auftrag gestartet. Report kommt über den Research Bot." |

### Nathan SOUL.md Anpassung
Bisherige Regel: "Nathan recherchiert NICHT selbst → Spock spawnen"
Neue Regel: "Nathan recherchiert NICHT selbst → `research-workflow` Skill triggern → n8n macht die Arbeit"

### Migrations-Roadmap (nach Research-Workflow)
1. **MiniFlux Sync** → n8n (Sample-Workflow existiert bereits)
2. **KB Population Pipeline** → n8n (kb-claim-extractor + verifier + contradiction-detector)

---

## 14. Error Handling & Resilience

### Fallback-Ketten
| Node-Typ | Primary | Fallback 1 | Fallback 2 |
|---|---|---|---|
| Search (Web) | Brave | Tavily | Gemini Grounding |
| Search (Deep) | Gemini CLI | You.com API | Brave + Tavily |
| Search (Social) | Grok API | Tavily (News) | — |
| CLI (Planning) | Codex CLI | Gemini CLI | Claude CLI |
| CLI (Judge) | Gemini CLI | Claude CLI | Codex CLI |
| CLI (Synthese) | Claude CLI (Opus) | Gemini CLI | Codex CLI |

### Retry-Strategie
| Fehler | Aktion |
|---|---|
| 429 Rate Limit | Exponential Backoff (1s→2s→4s→8s, max 30s) |
| 5xx Server Error | 3 Retries mit 5s Pause |
| 401/403 Auth Error | Kein Retry — sofort Fallback-Provider |
| Timeout | Node-spezifisch (Search: 60s, LLM: 120s, Quality Gate: 300s) |

### Circuit Breaker
Provider 3× hintereinander gefailed → 15min Cooldown → nur Fallback → Telegram-Notification.

---

## 15. Implementierungs-Roadmap

### Sprint 1 — MVP Pipeline (KW 15-16)

**Tag 1: Infrastruktur**
- SurrealDB `research/workflow` Namespace + Unified Schema deployen
- Research Bot Token in n8n konfigurieren
- n8n Credentials: Brave, Tavily, SurrealDB, MiniFlux
- CLIs testen: `gemini -p`, `claude -p`, `codex exec` auf B-Link

**Tag 2-5: n8n Workflows**
- `research-orchestrator` (Webhook + Manual Trigger + Adaptive Routing)
- `research-phase0-plan` (Codex CLI: Query → Search Plan + Modus-Klassifizierung)
- `research-search-web` + `research-search-kb` + `research-search-miniflux`
- `research-phase1-gather` (Parallel → Merge → Dedup)
- `research-phase4-synthesize` (Gemini CLI, Template v3)
- `research-deliver` (Research Bot + SurrealDB)

**Tag 5-6: OpenClaw Integration**
- Skill `research-workflow` erstellen
- Nathan SOUL.md anpassen

**Tag 6-7: Test**
- E2E-Run: "Vergleich React vs. Svelte 2026" (Quick + Standard Modi)
- Report via Research Bot empfangen
- Run in SurrealDB gespeichert

**Gate:** 1 Research-Run E2E, Report via Research Bot zugestellt

### Sprint 2 — Verification + Search Expansion (KW 16-17)
- Gemini CLI Search Grounding Branch (Deep Research Ersatz)
- Grok 4 API DeepSearch Branch (Social/X)
- Phase 2 (Counter-Research: Claude CLI Opus)
- Phase 3 (CoVe via research-quality-gate.py + Judge via Gemini CLI)
- Adaptive Pipeline-Tiefe Routing (Quick/Standard/Deep)
- Gate-Logik (Pass/Fail/Retry)
- HITL (Telegram Inline Buttons)

**Gate:** Quality Gate automatisch, Quellen in Portal verwaltbar

### Sprint 3 — Full Stack (KW 17-18)
- Academic Branch (Semantic Scholar + ArXiv)
- You.com Research API Branch (optional, Deep-Modus)
- YouTube Integration (yt-transcript.py + Gemini Summarization)
- FActScore
- Source-Reputation-Tracking
- KB-Writeback (Claims → openclaw/knowledge)
- Fallback-Ketten + Circuit Breaker
- Portal: Source Detail + Quality Badges + User-Rating + Kosten

**Gate:** 5 Runs < 30min, ≥80% Claims verified, Portal voll nutzbar

### Sprint 4 — Spezial-Modi + Portal (KW 18-19)
- Weekly Digest Workflow (Multi-Domain, Schedule Trigger)
- Produktvergleich + Domain-Modi
- Feedback-Loop (Rating → Prompt-Optimierung)
- Portal: Export (Markdown/PDF/NotebookLM) + Creator CRUD + Stats

### Sprint 5 — Optimierung (KW 19-20)
- Caching-Layer (ähnliche Queries → cached Results in SurrealDB)
- MCP Server Node (n8n als Tool für Claude Code — bidirektional)
- Source Feedback Loop (👍/👎 → Reputation)
- Creator Discovery Agent
- Exa Integration (Semantic Neural Search)
- NotebookLM API-Integration

---

## 16. Metriken & Erfolgskriterien

| Metrik | Target | Messung |
|---|---|---|
| Strukturierte Recherche | 100% Reports folgen Prozess | Template v3 Compliance |
| Claim Verification Rate | ≥80% Claims verified | Verified / Total Claims |
| Quellenqualität | ≥10 Quellen, ≥3 Plattformen | Pro Report |
| Durchlaufzeit | <30 Minuten | 90th Percentile |
| Gate Pass Rate | ≥70% First-Pass | First-Pass / Total Runs |
| HITL Trigger Rate | <15% | HITL-Runs / Total |
| KB Growth | ≥5 verifizierte Claims | Pro Report |
| User Satisfaction | ≥85% positiv | 👍/👎 Bewertung |
| Cost per Report | Tracking (kein festes Ziel) | Token-Kosten pro Phase |

---

## 17. Bereitgestellte Ressourcen

### CLIs (auf B-Link R2D2)
| CLI | Version | Status |
|---|---|---|
| `gemini` | v0.32.1 | ✅ Installiert, Auth konfiguriert |
| `claude` | v2.1.92 | ✅ Installiert, Auth konfiguriert |
| `codex` | v0.112.0 | ✅ Installiert, Auth konfiguriert |

### API Keys (in `~/.openclaw/.env`)
| Service | Kosten | Status |
|---|---|---|
| Brave Search | $5/Mo Credit | ✅ |
| Tavily | Free Tier (1K/Mo) | ✅ |
| Grok/xAI | Usage-based | ✅ |
| You.com Research | $100 Free Credit | 🔧 Einrichten |
| MiniFlux | Self-Hosted | ✅ |
| SurrealDB | Self-Hosted | ✅ |
| Research Bot (Telegram) | Kostenlos | ✅ |

### Infrastruktur (B-Link R2D2 — lokal, 24/7)
| System | URL / Port | Status |
|---|---|---|
| n8n | Docker `n8n-local`, `localhost:5678` (B-Link R2D2) | ✅ Läuft |
| SurrealDB | `localhost:8001` | ✅ Läuft, v3.0.0 |
| MiniFlux | `starfleet-rss.etrox.de` (Migration geplant) | ✅ Läuft |
| Nexus Portal | `~/projects/ai-portal/` | ✅ Walking Skeleton ready |

### Bestehende Scripts (wiederverwenden)
| Script | Zeilen | Funktion | n8n-Verwendung |
|---|---|---|---|
| `research-quality-gate.py` | ~1040 | CoVe + FActScore + Judge | Phase 3 (Code Node) |
| `kb-search.py` | ~300 | Hybrid GraphRAG Search | Phase 1 KB-Branch |
| `yt-transcript.py` | ~200 | YouTube Transkription | Phase 1 YouTube-Branch |
| `kb-miniflux-sync.py` | — | MiniFlux → SurrealDB Sync | Phase 1 MiniFlux-Branch |

### Dokumentation
| Datei | Inhalt |
|---|---|
| `docs/n8n-workflow-specs.md` | Technische Sub-Workflow-Spezifikationen |
| `schema/research-workflow.surql` | SurrealDB Schema (direkt deploybar) |
| `portal/PLUGIN-SPEC.md` | Nexus Portal Plugin-Spezifikation |
| `docs/ai-research-workflow-multi-agent-n8n.md` | Research Report: Multi-Agent Architektur |
| `docs/perplexity-research-workflow.md` | Research Report: Perplexity + Research Process |
# The Perfect AI Research Workflow
## Multi-Agent n8n Architecture with Verification, Validation & Knowledge Base

***

## Executive Summary

This report designs a best-in-class, fully automated research workflow built on **n8n** with a multi-provider LLM stack (OpenAI GPT-5, Claude 4.5, Gemini 3, and Grok 4), specialized research agents, structured quality gates, adversarial validation, and an end-to-end knowledge base pipeline into Notion/Obsidian. The system handles any research domain — finance, software architecture, vacation planning, social trends — by decomposing queries into parallel sub-tasks, executing them through domain-specialized agents, verifying results through an independent validator and a Red Team challenger, and only graduating sources that survive scrutiny into the final knowledge base.

The design is grounded in the **VMAO (Verified Multi-Agent Orchestration)** framework, Anthropic's production orchestrator-worker pattern, and best practices from the n8n production deployment guide.[^1][^2][^3][^4][^5][^6]

***

## Part 1: Foundational Architecture

### The Orchestrator-Worker Pattern

The backbone of best-in-class multi-agent research is the **orchestrator-worker (hub-and-spoke) architecture**. A lead orchestrator agent decomposes the research query, assigns sub-tasks to specialized workers operating in parallel, collects their outputs, and routes them through verification before synthesis. This pattern was independently validated by Anthropic's production Research system, which demonstrated that parallel subagents acting as "intelligent filters" dramatically outperform single-agent research.[^7][^2]

The key insight from the VMAO research framework is the five-phase loop: **Plan → Execute → Verify → Replan → Synthesize**. Queries are broken into a Directed Acyclic Graph (DAG) of sub-questions with dependency-aware parallel execution. A dedicated verifier evaluates completeness and triggers replanning when gaps are identified, looping until a configurable stop condition is met (e.g., completeness score > 0.8 or a maximum of 3 iterations). This approach improved answer completeness from 3.1 to 4.2 and source quality from 2.6 to 4.1 (on a 1–5 scale) compared to single-agent baselines.[^4][^5]

### Three-Tier Agent Taxonomy

Agents are organized into three functional tiers that reflect the natural information flow:[^4]

| Tier | Function | Agents |
|------|----------|--------|
| **Tier 1 — Data Gathering** | Retrieve raw information from all source types | Web Agent, Academic Agent, Social Agent, YouTube Agent, Creator Monitor Agent |
| **Tier 2 — Analysis** | Reason over gathered data, extract insights | Domain Analyst, Cross-Source Synthesizer, Devil's Advocate (Red Team) |
| **Tier 3 — Output** | Produce final deliverables and persist to knowledge base | Report Writer, Source Validator, Knowledge Base Exporter |

***

## Part 2: The LLM Stack

Different agents should run different models based on their task profile. Using GPT-4o-mini for narrow repetitive tasks (scraping, classification) versus a frontier model for orchestration reduces total per-run cost by roughly 65%.[^8]

### Model Assignments

| Model | Role in Workflow | Strengths |
|-------|-----------------|-----------|
| **GPT-5.1 / o3** | Orchestrator, Planner, final Synthesizer | Controllable reasoning depth via Thinking Mode; best for headless planning in complex domains[^9]; cached input pricing offers 90% discounts for repeated context in agentic loops[^9] |
| **Claude 4.5 Opus** | Domain Analyst, Report Writer, Verifier | Best for coding, structured tasks, safe enterprise outputs; outperforms on rigorous benchmarks and long-task execution[^10]; 200K context window handles large documents[^11] |
| **Gemini 3 / 2.5 Pro** | Academic Research Agent, Long-Document Processor | Best overall benchmark performance; 1M–2M token context ideal for large corpora of papers[^12][^10]; excels at long-form reasoning and multimodal inputs |
| **Grok 4** | Social Media Agent, Real-Time Trends Agent | Native multi-agent architecture with Harper sub-agent accessing ~68M English tweets/day via X firehose for millisecond-level real-time grounding[^13]; built-in DeepSearch for multi-step research with live citations[^14][^15] |
| **GPT-4o-mini** | Web Scraper Agent, Classification, Deduplication | Near-identical performance to frontier models on narrow structured extraction at ~10× lower cost[^8] |

### Integrating Grok 4 in n8n

Grok 4 is available as a native **xAI Grok Chat Model** node in n8n. Since xAI uses an OpenAI-compatible API format, it can also be configured via the OpenAI node pointing to `x.ai/api`. To enable real-time search, pass `search_parameters: {mode: "auto"}` in the request body. This unlocks Grok's DeepSearch capability — particularly valuable for social sentiment, breaking news, and X/Twitter trend research where recency is critical.[^16][^17][^18]

***

## Part 3: Specialized Research Agents

### 3.1 Web Research Agent

**Model:** GPT-4o-mini (scraping) + Claude 4.5 (synthesis)  
**Tools in n8n:**

- **Tavily Search Tool** — agent-optimized real-time web search with domain filters, time ranges, and topic filters; official n8n integration available[^19][^20]
- **Firecrawl** — full-page content extraction with autonomous Agent endpoint for multi-hop research; flat-rate pricing predictable for production[^21][^22]
- **Exa** — semantic neural search for discovery; pairs well with Firecrawl for extraction[^21]
- **SerpAPI** — Google/Bing SERP results with organic, FAQ, and related query extraction[^23][^24]
- **Perplexity Sonar API** — conversational multi-hop research with built-in citations[^25][^21]

**Process:** Query → parallel Tavily + Firecrawl + SerpAPI calls → deduplicate URLs → extract full content → score by source credibility → return structured JSON to orchestrator.

### 3.2 Academic Research Agent

**Model:** Gemini 2.5 Pro (large context for PDFs) + GPT-5.1 (query decomposition)  
**Tools in n8n:**

- **Semantic Scholar API** — accesses 200M+ academic papers with paper relevance search, citation networks, author profiles, SPECTER embeddings, and 23 discipline filters; supports DOI, arXiv ID, PubMed ID lookups[^26][^27]
- **ArXiv API** — preprint papers, critical for AI/ML topics (HTTP Request node)
- **OpenAlex API** — 250M+ open scholarly works (HTTP Request node)[^28]
- **CrossRef** — citation verification and DOI resolution[^29]

**Process:** Topic → LLM-guided decomposition into search queries → multi-granularity retrieval across APIs → semantic deduplication → citation verification against CrossRef + ArXiv → relevance scoring → abstract + key findings extraction.

The AutoResearchClaw pipeline (open-source, 23-stage) demonstrates a 4-layer citation verification system that cross-checks all references against ArXiv, CrossRef, DataCite, and an LLM judge — directly targeting hallucinated citations.[^30][^29]

### 3.3 Social Media Research Agent

**Model:** Grok 4 (X/Twitter, real-time) + GPT-4o-mini (structured extraction)  
**Tools in n8n:**

- **Apify** — most complete social scraping suite; actors available for LinkedIn, Instagram, TikTok, Reddit, Facebook, YouTube comments, and Google[^31][^32][^33]
- **ScrapeCreators** — single cheap API for 9 platforms (Google, Meta, LinkedIn, Reddit, and more) via one n8n HTTP node[^34][^35]
- **Grok 4 with DeepSearch** — real-time X/Twitter sentiment, trends, influencer posts[^13][^14]
- **Google Trends** — via HTTP Request node to Trends API[^36]

**Platform-Specific Actors (Apify):**
- LinkedIn: posts, profile data, company pages
- Instagram: posts, reels, hashtags, follower counts
- YouTube: channel data, comments, transcripts
- Reddit: subreddit threads, sentiment, upvotes
- TikTok: trending content, creator profiles

### 3.4 YouTube Research Agent

**Model:** Gemini 2.5 Pro (video transcription, long content) + GPT-4o-mini (scoring)  
**Tools in n8n:**

- **YouTube Data API v3** — official node; fetches channel IDs, video metadata, view counts, like counts[^37]
- **Apify YouTube Transcript Actor** — extracts full video transcripts, bypasses YouTube scraping limits[^38][^39][^40]
- **n8n YouTube Channel Monitor Template (#9268)** — ready-made workflow that polls channels from Google Sheets, transcribes with Gemini, scores relevance 1–10, saves to Google Sheets[^37]

**Process:** Trusted Creator List (Google Sheets) → Schedule Trigger (hourly/daily) → YouTube API fetch recent videos per channel → duplicate check → Apify transcript extraction → Gemini transcription + AI summary (500 words) → relevance score 1–10 based on topic criteria → save to Knowledge Base → flag high-relevance for human review.

### 3.5 Trusted Content Creator Monitor Agent

This is a dedicated **always-on monitoring sub-workflow** — separate from ad-hoc research runs — that continuously watches a curated list of trusted creators across all platforms.

**Creator Registry (Google Sheets / Notion Database):**

| Field | Description |
|-------|-------------|
| `creator_id` | Unique identifier |
| `name` | Creator/publication name |
| `platform` | YouTube / X / LinkedIn / Substack / Reddit / Blog |
| `channel_url` | Profile/channel URL |
| `rss_feed_url` | RSS URL if available (blogs, Substack, podcasts) |
| `youtube_channel_id` | For YouTube monitoring |
| `x_handle` | For Grok/X monitoring |
| `trust_level` | High / Medium / Watch (for weighting in synthesis) |
| `domain_tags` | e.g. `["AI", "finance", "architecture"]` |
| `last_checked` | Timestamp |
| `active` | Boolean toggle |

**Monitoring Tools by Platform:**

- **YouTube channels** → YouTube Data API v3 + Apify transcript[^41][^37]
- **Blogs / Substack / newsletters** → n8n RSS Feed node (built-in)[^42][^43][^44]
- **X/Twitter accounts** → Grok 4 API with DeepSearch (real-time firehose)[^13]
- **LinkedIn** → Apify LinkedIn scraper (triggered on schedule)[^31]
- **Reddit users/subreddits** → ScrapeCreators or Apify Reddit actor[^34]

**Process:** Schedule (every 6 hours) → read active creators from Registry → route by platform → fetch new content since last_checked → AI summarize → relevance-score against active research topics → if score ≥ 7, inject into active research context → update last_checked → push high-relevance items to Knowledge Base with `creator_trusted = true` flag.

The RSS-based content monitoring workflow demonstrated with n8n processes subscribed feeds every hour, uses an LLM to acquire and organize article content, and pushes to messaging platforms (Telegram/Slack) for real-time alerts.[^45]

***

## Part 4: Verification, Validation & Quality Gates

This is the most critical differentiator between a toy pipeline and production-grade research. The system implements four independent verification layers.

### Gate 1 — Source Credibility Scoring

Every retrieved source is scored before content extraction. A three-agent pipeline (Content Analyzer → Scientific/Source Verifier → Credibility Assessor) was validated in a published multi-agent AI pipeline study that demonstrated "substantial agreement with expert assessments" while providing "dramatic speed improvements".[^46]

**Credibility dimensions:**
- Domain authority and publication reputation
- Author credentials and citation count
- Publication recency
- Cross-source corroboration count
- Trusted Creator flag (sources from your Creator Registry get a trust bonus)

**Output:** Credibility score 0–100 per source; sources below threshold (e.g., < 40) are excluded from synthesis but retained in audit log.

### Gate 2 — Hallucination Validation Pipeline

Every claim in synthesized content passes through a **Hallucination Validation Pipeline (HVP)**:[^47][^48][^49]

1. **RAG Layer** — every response grounded in retrieved documents with explicit citations; claims without citation are flagged
2. **Source Validation Engine** — compares generated claims against structured source data; flags inconsistencies[^47]
3. **Factuality & Consistency Scoring** — secondary model (different model family from generator to reduce correlated failures) scores factual alignment; outputs hallucination score[^50]
4. **Retrieval-Augmented Verification** — each generated claim evaluated against search index; unsupported claims are rejected, revised, or regenerated with grounding[^49]

The use of a different model family for validation (e.g., GPT-5 generates, Claude validates) is a deliberate architectural diversity choice to reduce correlated failure modes.[^50]

### Gate 3 — The Devil's Advocate (Red Team Agent)

This is the adversarial challenge run that Nico specifically requested — an agent whose sole job is to **refute, challenge, and stress-test** the synthesized findings.

**Model:** Claude 4.5 Opus (strongest adversarial reasoning)

**System Prompt Pattern:**
> "You are a rigorous Devil's Advocate. You will receive a research synthesis and its sources. Your job is to: (1) identify logical fallacies, (2) find contradicting evidence not in the synthesis, (3) challenge the weakest factual claims, (4) propose alternative interpretations. For each challenge, rate your confidence 0–1 and cite a source. Output as structured JSON."

**Process:** Synthesis → Red Team Agent runs independent Tavily/Firecrawl search for contrary evidence → generates structured rebuttal with confidence scores → rebuttal returned to Synthesizer → Synthesizer produces revised synthesis addressing valid challenges → claims that survive adversarial challenge are marked `verified = true`.[^51][^52][^53]

Research on automated red-teaming demonstrates that even the safest agents still have non-zero failure rates when exposed to unreliable sources (Claude-Sonnet-4.5 with tool-calling: 4.6% ASR), making independent adversarial testing essential rather than optional.[^52]

### Gate 4 — LLM-as-a-Judge Final Quality Gate

A final judge agent evaluates the complete research package before it is written to the Knowledge Base.[^2]

**Evaluation dimensions (score 0.0–1.0 per dimension):**

| Dimension | Threshold |
|-----------|-----------|
| Completeness — all sub-questions answered | ≥ 0.80 |
| Source quality — credibility-weighted average | ≥ 0.70 |
| Factual consistency — no unresolved contradictions | ≥ 0.85 |
| Adversarial survival — red team challenges addressed | ≥ 0.75 |
| Citation density — every claim cited | ≥ 0.90 |

If any dimension falls below threshold, the orchestrator triggers a **Replan** loop — generating new sub-questions targeting the gap — up to a maximum of 3 iterations. This was validated in the VMAO framework where verification-driven replanning produced the largest quality gains.[^5][^4]

Human-in-the-Loop (HITL) gates are triggered for high-stakes outputs (finance reports, legal analysis) where human review is mandatory before knowledge base commit.[^1][^47]

***

## Part 5: The Complete n8n Workflow Architecture

### Master Workflow Structure

```
[Trigger: Webhook / Schedule / Chat]
        │
        ▼
┌─────────────────────────┐
│  ORCHESTRATOR AGENT      │  ← GPT-5.1 (Planner)
│  Query decomposition     │
│  DAG sub-task planning   │
│  Agent role assignment   │
└────────────┬────────────┘
             │ Execute Sub-Workflows (parallel)
    ┌────────┼────────┬────────────┬─────────────┐
    ▼        ▼        ▼            ▼             ▼
[Web      [Academic [Social     [YouTube    [Creator
 Agent]    Agent]    Agent]      Agent]      Monitor]
GPT-4o-   Gemini    Grok 4 +   Gemini +    Schedule
mini +    2.5 Pro   GPT-4o-    Apify       (always-on)
Firecrawl Semantic  mini       YouTube
Tavily    Scholar   Apify      API v3
SerpAPI   ArXiv     ScrapeCreators
             │
             ▼ Tier 1 results → Orchestrator
┌─────────────────────────┐
│  SYNTHESIZER AGENT       │  ← Claude 4.5
│  Cross-source merging    │
│  Initial report draft    │
└────────────┬────────────┘
             ▼
┌─────────────────────────┐
│  VERIFICATION PIPELINE   │
│  Gate 1: Source scoring  │
│  Gate 2: HVP             │
│  Gate 3: Red Team        │  ← Claude 4.5 (adversarial)
│  Gate 4: Judge           │
└────────────┬────────────┘
             │ Pass / Fail
    ┌────────┴──────────┐
    ▼                   ▼
[REPLAN loop]    [APPROVED → Knowledge Base Export]
(max 3 iter)     ↓
                 Notion / Qdrant vector store
                 Only verified sources committed
```

### Sub-Workflow Modular Design

Each agent runs as an **independent n8n sub-workflow** called via the Execute Sub-workflow node. This is the key production pattern: each sub-workflow has a defined input schema, defined output schema, can be independently tested, independently debugged, and updated without touching the orchestrator. The production best-practice rule: if a workflow exceeds 15–20 nodes or has more than 3 branching paths, refactor to sub-workflows.[^54][^6][^8]

**Key sub-workflows:**
- `research-web-agent` — Tavily + Firecrawl + SerpAPI
- `research-academic-agent` — Semantic Scholar + ArXiv + CrossRef
- `research-social-agent` — Apify + ScrapeCreators + Grok
- `research-youtube-agent` — YouTube API + Apify transcripts
- `creator-monitor` (always-on) — RSS + YouTube API + Grok
- `hallucination-validator` — source check + consistency scoring
- `red-team-agent` — adversarial challenge
- `llm-judge` — final quality gate
- `knowledge-base-exporter` — Notion + Qdrant writer

***

## Part 6: Domain-Specific Research Modes

The orchestrator routes to different agent configurations depending on the research topic. The prompt includes domain classification logic that detects query type before dispatching.

### Finance Research Mode

**Agents activated:** Web Agent (Tavily + financial domains), Academic Agent (SSRN, economics papers), Social Agent (X sentiment via Grok, Reddit r/investing), YouTube Agent (financial YouTubers)

**Special tools:** Perplexity Sonar API for live financial data synthesis; SerpAPI with domain filter `site:sec.gov OR site:ft.com OR site:bloomberg.com`[^21]

**Privacy note:** For sensitive financial data, prefer local open-source models (Llama 4, Mistral) to avoid cloud data exposure. Cloud models offer superior fluency but raise data privacy concerns in financial contexts.[^55]

**Trusted Creator examples (pre-populate in Registry):** Financial YouTube channels, Substack finance newsletters, specific X accounts.

### Software Architecture Research Mode

**Agents activated:** Web Agent (Firecrawl for docs, GitHub), Academic Agent (ArXiv cs.SE, ACM Digital Library), Social Agent (Reddit r/softwarearchitecture, Dev.to), YouTube Agent (tech conference talks)

**Special tools:** Exa semantic search for discovering related technical content; Firecrawl for full documentation extraction[^22][^21]

**Trusted Creator examples:** Tech conference YouTube channels (GOTO, InfoQ), architecture newsletter authors, principal engineers on X.

### Vacation Planning Research Mode

**Agents activated:** Web Agent (travel sites, reviews), Social Agent (Reddit r/travel, TikTok travel creators), YouTube Agent (travel vloggers from creator list)

**Special tools:** Tavily with `topic: general` and time range filter for current conditions; Apify for TripAdvisor/Booking review scraping[^19]

**Multi-agent travel planning systems** like VacayMate demonstrated that 5 specialized agents (flights, accommodation, activities, budget, itinerary) with real-time data significantly outperform single-agent approaches.[^56]

***

## Part 7: The Knowledge Base & Source Registry

### Architecture

Only sources that survive the full verification pipeline (Gates 1–4) are committed to the knowledge base. Every source carries a structured metadata record:

```json
{
  "source_id": "uuid",
  "url": "https://...",
  "title": "...",
  "domain": "finance | tech | travel | academic",
  "source_type": "web | academic | social | youtube | creator",
  "creator_trusted": true,
  "creator_name": "...",
  "credibility_score": 87,
  "hallucination_checked": true,
  "adversarial_survived": true,
  "judge_score": 0.91,
  "run_id": "research-run-2026-04-06",
  "research_query": "...",
  "extracted_at": "ISO timestamp",
  "citation": "APA formatted"
}
```

### Notion Knowledge Base Integration

The n8n Notion Knowledge Base AI Assistant (official template) uses an AI Agent with RAG to query the Notion database, provides reference links to exact pages used, and offers full conversational access to the knowledge store. The setup:[^57][^58]

1. n8n writes verified source records to a Notion database via the Notion node
2. A separate n8n RAG agent uses the Notion node + OpenAI embeddings to answer queries
3. Every response includes the Notion page link for direct verification[^57]

### Vector Store (Qdrant — Self-Hosted)

For semantic search across all accumulated research, Qdrant is the recommended self-hosted vector store (aligns with your self-hosted n8n setup). The n8n Qdrant Vector Store node supports Insert, Get, Retrieve (as Tool for AI Agent), and Retrieve (as Vector Store for Chain).[^59][^60]

**Pipeline:** Verified source → chunk text → OpenAI `text-embedding-3-small` embeddings → upsert to Qdrant collection → n8n AI Agent with Qdrant as tool for semantic retrieval.[^61][^60]

For NotebookLM integration, the Apify NotebookLM API actor exports notebooks in JSON/CSV/Markdown with source URLs, citation mappings, and AI-generated summaries — ready to feed directly into RAG pipelines or n8n workflows.[^62]

### The Source Registry for Notebook Knowledge Base

At the end of every research run, a final workflow exports:
1. **Verified sources list** (only sources that passed all gates) → Notion source database
2. **Rejected sources log** (with reason: credibility fail / hallucination fail / red-team refuted) → separate audit table
3. **Research run manifest** (query, run_id, timestamp, agent configs, model versions) → run log
4. **Vector embeddings** of all verified content → Qdrant for semantic retrieval

This means only the sources that are "really valid" (as you specified) are committed to the notebook — the rejected sources never enter the knowledge base but are traceable in the audit log.

***

## Part 8: n8n Production Configuration

### Infrastructure

- **Deployment:** Self-hosted n8n on Docker (aligns with your existing setup)[^1]
- **Queue mode** for parallel agent execution — critical for running 5 agents simultaneously[^1]
- **Workers:** minimum 3–5 worker processes for parallel sub-workflow execution

### AI Agent Guardrails (Production Checklist)[^6]

- [ ] AI output validated before any downstream action triggers
- [ ] Each agent has only the tools needed for its specific task (principle of least privilege)
- [ ] Human-in-the-loop gates for high-stakes outputs (finance, medical)
- [ ] Kill switch per agent workflow — pausable without infrastructure changes
- [ ] Prompts versioned separately from workflow logic
- [ ] Model versions pinned — silent model updates must not change behavior
- [ ] Max 15–20 nodes per workflow; overflow goes to sub-workflows

### Error Handling Pattern

Every sub-workflow wraps agent calls in error handling nodes. If a Research Agent sub-workflow fails, the orchestrator catches the error, logs it, and either retries (up to 3×) or marks that data tier as partial — synthesis proceeds with available data rather than halting entirely.[^63][^1]

### Cost Optimization

- Route classification and deduplication to GPT-4o-mini
- Use Gemini 2.5 Pro for high-volume document processing (cheapest frontier model at $1.25/$5 per M tokens)[^11]
- Enable OpenAI cached inputs for repeated orchestrator context (90% discount)[^9]
- Use Qdrant self-hosted to avoid ongoing vector DB fees

***

## Part 9: Trusted Content Creator Registry — Implementation

### Initial Population

Populate the Creator Registry with a Google Sheets or Notion database containing creators across these categories (add/remove as needed):

| Category | Platform | Examples to Consider |
|----------|----------|---------------------|
| AI/ML Research | YouTube + X | AI lab channels, ML conference recordings |
| Finance | YouTube + Substack + X | Financial analysts, macro economists |
| Software Architecture | YouTube + Blog | Principal engineers, CTO blogs, GOTO/InfoQ |
| Venture & Startup | X + Substack | VC firms, founder newsletters |
| News & Journalism | RSS + X | Tech publications with RSS feeds |
| Domain Experts | Platform varies | Per-topic specialists you personally vet |

### Creator Discovery Sub-Agent

An optional **Creator Discovery Agent** can auto-discover new trusted creators by:
1. Monitoring which sources appear repeatedly in high-scoring research runs
2. Using YouTube API to identify channels posting in topic areas with high engagement[^64]
3. Presenting candidates to the human (HITL gate) for approval before adding to Registry

New creators enter with `trust_level: Watch` and are upgraded to `trust_level: High` only after their content has been validated in multiple research runs.

***

## Part 10: Full Source Quality Lifecycle

```
┌──────────────────────────────────────────────────────────┐
│                   RESEARCH RUN LIFECYCLE                   │
│                                                            │
│  1. Query ingestion + domain classification                │
│  2. Orchestrator DAG planning                              │
│  3. Parallel Tier-1 agent execution (web/academic/social/ │
│     YouTube/creator monitor)                               │
│  4. Source credibility scoring (Gate 1)                    │
│     → Sources < threshold → REJECTED (audit log)          │
│  5. Cross-source synthesis (Claude 4.5)                    │
│  6. Hallucination validation (Gate 2)                      │
│     → Failed claims flagged → regenerated with grounding  │
│  7. Devil's Advocate / Red Team challenge (Gate 3)         │
│     → Refuted claims removed or challenged in report      │
│  8. LLM-as-Judge final score (Gate 4)                      │
│     → Score < threshold → REPLAN (max 3 iterations)       │
│  9. HITL review for high-stakes domains                    │
│  10. Approved → write to Knowledge Base                    │
│      ✓ Notion source database (verified sources only)     │
│      ✓ Qdrant vector store (semantic search)               │
│      ✓ Research run manifest (full audit trail)            │
│      ✗ Rejected sources → audit log (never in notebook)   │
└──────────────────────────────────────────────────────────┘
```

***

## Part 11: Reference Tools & APIs Summary

### n8n Nodes Required

| Node | Purpose |
|------|---------|
| AI Agent | Core agent logic, tool orchestration |
| Execute Sub-workflow | Modular agent calls |
| OpenAI Chat Model | GPT-5.1, GPT-4o-mini |
| xAI Grok Chat Model | Grok 4 with DeepSearch |
| Google Gemini Chat Model | Gemini 3 / 2.5 Pro |
| Anthropic Claude | Claude 4.5 Opus |
| HTTP Request | Semantic Scholar, ArXiv, OpenAlex, Grok API, YouTube API, ScrapeCreators |
| Apify | Social scraping, YouTube transcripts, NotebookLM export |
| Tavily | Real-time web search |
| RSS Feed | Creator blog/Substack monitoring |
| YouTube (built-in) | Channel data, video metadata |
| Qdrant Vector Store | Self-hosted semantic vector DB |
| Notion | Knowledge base write/read |
| Google Sheets | Creator Registry, dedup log, results |
| Schedule Trigger | Creator monitor (every 6h) |
| Webhook | On-demand research trigger |
| Evaluations Trigger | n8n Evals quality testing |
| Wait | Rate limiting |
| If / Switch | Quality gate routing |
| Loop Over Items | Batch processing |

### External APIs & Services

| Service | Use | Pricing Model |
|---------|-----|---------------|
| OpenAI API | GPT-5.1, GPT-4o-mini, embeddings | Per token |
| Anthropic API | Claude 4.5 Opus | Per token |
| Google AI | Gemini 3 / 2.5 Pro | Per token |
| xAI API (x.ai/api) | Grok 4 + DeepSearch | Per token |
| Tavily | Web search | Per request |
| Firecrawl | Full-page scraping | Credits |
| Exa | Semantic search | Credits |
| SerpAPI | SERP results | Per request |
| Apify | Social scraping, YouTube | Compute units |
| ScrapeCreators | Multi-platform social | Per request |
| Semantic Scholar | Academic papers | Free API |
| ArXiv | Preprint papers | Free API |
| OpenAlex | Open scholarly works | Free API |
| Perplexity Sonar | Deep research API | Per request |
| Qdrant | Vector DB | Self-hosted free |
| Pinecone | Vector DB (cloud alt.) | Free tier + usage |
| Notion API | Knowledge base | Free/Pro plan |
| YouTube Data API v3 | Channel/video data | Free quota |

***

## Conclusion

The ideal research workflow is not a single monolithic pipeline — it is a **coordinated system of specialized agents** operating in parallel, checked by independent validators, challenged by adversarial red-teaming, and filtered by strict quality gates before any source earns a place in the knowledge base. Built on n8n's modular sub-workflow architecture, this system scales from a single vacation-planning query to continuous multi-domain research intelligence.

The four-model stack (GPT-5.1 + Claude 4.5 + Gemini 3 + Grok 4) is not redundant — each model covers a distinct strength: planning, accuracy, scale, and real-time social grounding respectively. The Trusted Content Creator Registry transforms passive scraping into active intelligence from vetted human experts, whose outputs receive elevated trust weighting throughout the verification pipeline.

Sources that survive all four quality gates — credibility scoring, hallucination validation, adversarial challenge, and LLM judgment — become permanent, citable assets in a semantic knowledge base. Everything else is logged but never promoted, preserving knowledge base integrity across every research run.

---

## References

1. [15 best n8n practices for deploying AI agents in production](https://blog.n8n.io/best-practices-for-deploying-ai-agents-in-production/) - This guide covers the 15 best n8n practices for deploying AI agents that run reliably in production....

2. [How we built our multi-agent research system](https://www.anthropic.com/engineering/multi-agent-research-system)

3. [[PDF] Verified Multi-Agent Orchestration: A Plan-Execute-Verify-Replan ...](https://arxiv.org/pdf/2603.11445.pdf)

4. [Verified Multi-Agent Orchestration: A Plan-Execute-Verify-Replan ...](https://arxiv.org/html/2603.11445v1)

5. [Verified Multi-Agent Orchestration: A Plan-Execute-Verify-Replan Framework for Complex Query Resolution](https://arxiv.org/pdf/2603.11445v1.pdf)

6. [n8n Best Practices Checklist for Production (2026)](https://hatchworks.com/blog/ai-agents/n8n-best-practices/) - The 2026 n8n best practices checklist: six categories of production-ready standards for security, er...

7. [LLMs and Multi-Agent Systems: The Future of AI in 2025](https://www.classicinformatics.com/blog/how-llms-and-multi-agent-systems-work-together-2025) - Explore how LLMs and Multi-Agent Systems work together to tackle complex tasks and revolutionize AI ...

8. [Build a Multi-Agent Workflow in n8n (Orchestrator + Agents ...](https://www.innovatrixinfotech.com/blog/build-multi-agent-workflow-n8n) - Step-by-step: build a 3-agent n8n pipeline with orchestrator, research agent, and writer agent. Real...

9. [Best Agentic LLM Models & Frameworks 2026 - Adaline](https://www.adaline.ai/blog/top-agentic-llm-models-frameworks-for-2026) - A data-driven comparison of GPT-5.2, Gemini 3, and Claude 4.5—plus the framework battle determining ...

10. [Top 5 LLM Models in 2025: Gemini 3, Claude 4.5, GPT-5.1, Grok 4 ...](https://vertu.com/ai-tools/top-5-llm-models-in-2025-leading-ai-systems-shaping-the-future/) - Find the Top 5 LLM Models in 2025 including Gemini 3 (Multimodal), Claude 4.5 Opus (Enterprise/Accur...

11. [Claude vs GPT-4 vs Gemini: Which LLM for Production AI Agents?](https://getathenic.com/blog/anthropic-claude-vs-openai-gpt4-vs-google-gemini) - Comprehensive comparison of Claude 3.5 Sonnet, GPT-4o, and Gemini 1.5 Pro for building production AI...

12. [ChatGPT 5.1 vs Claude vs Gemini: A Balanced Comparison (2025)](https://skywork.ai/blog/ai-agent/chatgpt-5-1-vs-claude-vs-gemini-2025-comparison/) - ChatGPT 5.1 vs Claude vs Gemini: Compare 2025's latest AI models by reasoning modes, multimodality, ...

13. [HOW THE XAI GROK 4.20 AGENTS WORK | NextBigFuture.com](https://www.nextbigfuture.com/2026/02/how-the-xai-grok-4-20-agents-work.html) - – Official developer guides (2025) detail “manager pattern” (central LLM calls specialist agents as ...

14. [how to use grok ai for advanced research workflows 2026 - YouTube](https://www.youtube.com/watch?v=l46Y9PJD6DY) - In this video, you'll learn how to use Grok AI for advanced research workflows in 2026 step by step....

15. [Grok AI Assistant: The Complete 2026 Guide to xAI's Real-Time Model](https://skywork.ai/skypage/en/grok-ai-real-time-model-guide/2032304113992433664) - Explore xAI's Grok AI: real‑time X integration, multimodal tools, low‑cost API, and enterprise workf...

16. [Build AI Agent in n8n using xAI Grok!](https://www.youtube.com/watch?v=_F1CVi19n7I) - In this video I cover how you can easily plug in xAI's Grok API into your n8n workflow with their AI...

17. [xAI Grok Chat Model integrations | Workflow automation with n8n](https://n8n.io/integrations/xai-grok-chat-model/) - Integrate xAI Grok Chat Model with hundreds of other apps. Create sophisticated automations between ...

18. [How to Add Grok 4 to n8n AI Agents (+Vision and Real-Time Search)](https://www.youtube.com/watch?v=zo26u39LIbE) - 🚀 Access ALL video resources & get personalized help in my community:
https://www.skool.com/agentic-...

19. [Tavily + n8n — Real-time web data, low code](https://www.tavily.com/blog/building-autonomous-workflows-tavily-n8n-real-time-web-data-low-code) - This guide shows how combining Tavily's real-time search and extraction with n8n's low-code workflow...

20. [n8n - Tavily Docs](https://docs.tavily.com/documentation/integrations/n8n) - Tavily is now available for no-code integration through n8n.

21. [5 Best Deep Research APIs for Agentic Workflows in 2026 - Firecrawl](https://www.firecrawl.dev/blog/best-deep-research-apis) - Compare the top deep research APIs for building AI agents and agentic workflows. From autonomous web...

22. [Best AI Search Engines for Agents and Workflows in 2026 - Firecrawl](https://www.firecrawl.dev/blog/best-ai-search-engines-agents) - Not all AI search engines are built for agents. Here's a developer breakdown of the top options — Fi...

23. [Efficient SERP Analysis & Export Results to Google Sheets (SerpApi ...](https://www.reddit.com/r/n8n/comments/1kc5kin/efficient_serp_analysis_export_results_to_google/) - A set of free n8n templates for automating SERP analysis. I built these mainly to speed up keyword r...

24. [Build a Real-Time AI Agent with n8n & SERPAPI (No Code)](https://www.youtube.com/watch?v=aiEcHXAme0M) - **🔎 Build a Real-Time AI Search Agent with N8N & SERPAPI! 🚀**  

🔗 Join here: https://www.skool.com/...

25. [Top 10 Deep Research Agents in 2025 (Alici, Kimi, Gemini, Claude)](https://alici.ai/blog/top-deep-research-agents-2025) - In-depth 2025 comparison of Alici.ai Research Playbooks, Kimi-Researcher, OpenAI DeepResearch, Gemin...

26. [The Semantic Scholar Open Data Platform - arXiv](https://arxiv.org/html/2301.10140v2)

27. [Semantic Scholar Integration for AI Agents - Tars Chatbots](https://hellotars.com/tools/semanticscholar) - Connect Semantic Scholar to Tars AI Agents. Search papers, retrieve citations, and explore author pr...

28. [Scientific agents are getting a lot more real. AutoResearchClaw is ...](https://www.instagram.com/reel/DWZiXCpAcY9/) - rediminds on March 27, 2026: "Scientific agents are getting a lot more real. AutoResearchClaw is an ...

29. [AutoResearchClaw: Autonomous Multi-Agent System for End ...](https://agent-wars.com/news/2026-03-15-autoresearchclaw-paper-generation) - AutoResearchClaw is one of the most technically complete entries yet in the growing class of tools t...

30. [AutoResearchClaw: We Ran a Fully Autonomous Research Pipeline](https://themenonlab.blog/blog/autoresearchclaw-autonomous-research-pipeline) - Real results from running AutoResearchClaw's 23-stage autonomous research pipeline. Setup guide, art...

31. [How to Build a Social Media Scraper AI Agent with n8n](https://www.youtube.com/watch?v=QtNRH6mHWlA) - ♥️ *Get N8n Hosting & Workflow* ➜ https://webspacekit.com/client/link.php?id=182

❤️ *LIMITED TODAY:...

32. [I Built an AI Agent That Scrapes Social Media in Seconds (n8n + Apify Tutorial)](https://www.youtube.com/watch?v=Gj_ZKlcsXR8) - Full systems + unlimited support: https://go.mikefutia.com/scale-youtube

Work with me: https://go.m...

33. [7 Essential AI Agents Tools You Should Use in n8n! (2025) - YouTube](https://www.youtube.com/watch?v=i0FfNB4E6pM) - ... Firecrawl 05:01 API-Template.io 07:35 Apify 09:45 Mistral 11:46 Tavily 13:10 Pinecone If You're ...

34. [Scrape EVERY Social Media with n8n (CHEAP & EASY)](https://www.youtube.com/watch?v=PY1id4-m6NI&vl=en) - Check out scrapecreators here: https://scrapecreators.com/?via=scrapes

🚀 All my paid resources inc....

35. [Scrape EVERY Social Media with n8n (CHEAP & EASY)](https://www.youtube.com/watch?v=PY1id4-m6NI) - Check out scrapecreators here: https://scrapecreators.com/?via=scrapes

🚀 All my paid resources inc....

36. [Fully Automated Social Media Agent with n8n & Google Trends (No Code!) | Step by Step Tutorial](https://www.youtube.com/watch?v=3CQQwHh2K58) - Join Me on Telegram for getting useful resources-  https://t.me/+IZsBvr-jANc2Yzk1

Tired of manual c...

37. [YouTube channel monitor with Video Stats, AI transcription ... - N8N](https://n8n.io/workflows/9268-youtube-channel-monitor-with-video-stats-ai-transcription-and-summarization/) - This n8n workflow automatically monitors YouTube channels, transcribes new videos, and generates AI-...

38. [How to Scrape ANY YouTube Video Transcript with n8n! (full workflow)](https://my.infocaptor.com/hub/summaries/ai-foundations/how-to-scrape-any-youtube-video-transcript-with-n8n-full-workflow-pAOOfeKYaSQ) - The video demonstrates a three-part workflow for extracting YouTube transcripts and storing them in ...

39. [How to Scrape ANY YouTube Video Transcript with n8n! (full workflow)](https://www.youtube.com/watch?v=pAOOfeKYaSQ) - Master AI through courses and community: https://www.skool.com/ai-foundations Master AI agents in n8...

40. [Transcribe Video and Make Timestamps Using N8N - YouTube](https://www.youtube.com/watch?v=C3oakGaQfzE) - Learn how to auto transcribe videos and make timestamps using n8n, Open AI, and Apify.com. This work...

41. [Monitor multiple YouTube channels with real-time RocketChat alerts](https://n8n.io/workflows/10643-monitor-multiple-youtube-channels-with-real-time-rocketchat-alerts/) - This n8n workflow provides automated monitoring of YouTube channels and sends real-time notification...

42. [Automated blog content tracking with RSS feeds and time-based ...](https://n8n.io/workflows/9596-automated-blog-content-tracking-with-rss-feeds-and-time-based-filtering/) - This workflow provides a powerful yet simple foundation for monitoring blogs using RSS feeds. It aut...

43. [Auto Tech Newsletter from RSS: Free n8n AI Agent Workflow](https://hackceleration.com/automations-to-download/ai-agent-n8n-auto-tech-newsletter-rss/) - Download this free n8n AI agent that generates your daily tech newsletter automatically. Claude Sonn...

44. [Automated RSS feed workflow with n8n & Outlook - Kutzschbach](https://www.kutzschbach.de/en/rss-feed-workflow/) - A workflow was developed for this purpose: Automatic retrieval of RSS feeds from important websites ...

45. [Building Your Own RSS Feed Subscription Management & AI Large ...](https://dev.to/yeshan333/building-your-own-rss-feed-subscription-management-ai-large-model-reading-workflow-with-n8n-2lia) - Recently, I used n8n to orchestrate a workflow to replace my previous backend application rss_generi...

46. [Development and validation of a multi-agent AI pipeline for ... - PMC](https://pmc.ncbi.nlm.nih.gov/articles/PMC12757325/) - To validate the automated framework's credibility scores, two expert reviewers independently evaluat...

47. [How to Build a Hallucination Validation Pipeline for AI-Generated ...](https://www.linkedin.com/posts/rakesh-khanduja-61567913_how-to-build-a-hallucination-validation-pipeline-activity-7382644585392529408-SkyN) - How to Build a Hallucination Validation Pipeline for AI-Generated Content In the age of GenAI, conte...

48. [How to Test AI Reliability: Detect Hallucinations and Build End-to ...](https://www.getmaxim.ai/articles/how-to-test-ai-reliability-detect-hallucinations-and-build-end-to-end-trustworthy-ai-systems/) - AI reliability requires systematic hallucination detection and continuous monitoring across the enti...

49. [AI Hallucination Detection Tools: W&B Weave & Comet - AIMultiple](https://aimultiple.com/ai-hallucination-detection) - We benchmarked 3 AI hallucination detection tools across 100 test cases using identical datasets and...

50. [A Framework for Assessing AI Agent Decisions and Outcomes in ...](https://arxiv.org/html/2602.22442v2) - Modern agent-based AutoML systems model machine learning pipelines as sequences of interconnected de...

51. [Learning-Based Automated Adversarial Red-Teaming for ... - arXiv](https://arxiv.org/html/2512.20677v3)

52. [SafeSearch: Automated Red-Teaming of LLM-Based Search Agents](https://arxiv.org/html/2509.23694v4) - In response to the research question, our study highlights the overall high vulnerability of LLM-bas...

53. [[PDF] Red Teaming AI Systems for Security Validation](https://ijaibdcms.org/index.php/ijaibdcms/article/download/248/251) - A timeline of the evolution in AI threat views: adversarial examples (2017), data poisoning (2019), ...

54. [Multi-agent system: Frameworks & step-by-step tutorial - n8n Blog](https://blog.n8n.io/multi-agent-systems/) - Discover multi-agent AI patterns, communication, costs, risks, and real-world use cases. Compare vis...

55. [Comparing Open-Source and Commercial LLMs for Domain-Specific Analysis and Reporting: Software Engineering Challenges and Design Trade-offs](https://arxiv.org/abs/2509.24344) - Context: Large Language Models (LLMs) enable automation of complex natural language processing acros...

56. [VacayMate: When AI Agents Become Your Personal Travel Bureau](https://app.readytensor.ai/publications/vacaymate-when-ai-agents-become-your-personal-travel-bureau-RIAGyo2bgTBG)

57. [Notion knowledge base AI assistant | n8n workflow template](https://n8n.io/workflows/2413-notion-knowledge-base-ai-assistant/) - Who is this forThis workflow is perfect for teams and individuals who manage extensive data in Notio...

58. [How to Set Up a Notion Knowledge Base AI Assistant](https://www.youtube.com/watch?v=ynLZwS2Nhnc) - This video walks through set up of the Notion Knowledge Base AI Assistant (a project made by Max Tka...

59. [Qdrant Vector Store node documentation - n8n Docs](https://docs.n8n.io/integrations/builtin/cluster-nodes/root-nodes/n8n-nodes-langchain.vectorstoreqdrant/) - Learn how to use the Qdrant Vector Store node in n8n. Follow technical documentation to integrate Qd...

60. [N8N and Qdrant Vector Store: A Tutorial on RAG](https://www.convert.com/blog/ai/n8n-qdrant-vector-store-rag-tutorial/) - A guide to implementing Retrieval-Augmented Generation in n8n using Qdrant vector storage and Ollama...

61. [Pinecone Vector Store node documentation](https://docs.n8n.io/integrations/builtin/cluster-nodes/root-nodes/n8n-nodes-langchain.vectorstorepinecone/) - Learn how to use the Pinecone Vector Store node in n8n. Follow technical documentation to integrate ...

62. [NotebookLM API - Export Notebooks, Sources & Citations - Apify](https://apify.com/clearpath/notebooklm-api) - Output to JSON, CSV, Markdown or Excel. Bulk export or select specific notebooks. Perfect for n8n wo...

63. [[PDF] Verification-Aware Planning for Multi-Agent Systems - ACL Anthology](https://aclanthology.org/2026.eacl-long.353.pdf)

64. [[Paid] Need an n8n Agent to find YouTube creators by keywords ...](https://www.reddit.com/r/n8n/comments/1mq9rw8/paid_need_an_n8n_agent_to_find_youtube_creators/) - I'm looking to hire someone to build an n8n workflow (or set of workflows) that finds relevant YouTu...

# How Perplexity Works in a Research Workflow & The Real-World Research Process

***

## Executive Summary

This report covers two deeply connected subjects: (1) the internal technical architecture of Perplexity AI — from its six-stage RAG pipeline to its agentic Deep Research loop — and how it integrates into an automated n8n research workflow; and (2) the canonical real-world research process as practiced by professional and academic researchers, analyzed step by step so that the AI workflow can faithfully mirror it. Together, these form the theoretical and technical foundation of the perfect research system.

***

# Part I: How Perplexity Works

## What Perplexity Is (and Is Not)

Perplexity AI is fundamentally a **Retrieval-Augmented Generation (RAG) system** that prioritizes real-time web retrieval over LLM memorized knowledge. The critical architectural distinction is that the LLM in Perplexity acts as a **synthesizer bound by retrieved evidence** — not as the primary knowledge source. The search, filtering, ranking, and source assembly all happen *before* the language model is invoked. This is what makes Perplexity structurally different from asking GPT-5 a question directly: the answer is grounded in documents retrieved seconds before, not weights trained months ago.[^1]

Perplexity achieved a **93.9% accuracy score on the SimpleQA benchmark** in 2025, outperforming competitors by 4–8 percentage points. On the DRACO cross-domain benchmark for deep research, Perplexity (powered by Claude Opus 4.6) achieved the highest scores across all domains, with Law (90.2%) and Academic (82.8%) being the strongest.[^2][^3][^4]

***

## The Six-Stage RAG Pipeline (Standard Search)

Every query in standard Perplexity mode passes through six discrete operations before a word of the answer is generated:[^1]

### Stage 1 — Query Intent Parsing

The system classifies the query type: factual, procedural, comparative, or multi-part. Based on this classification, it routes the query to the appropriate index — time-sensitive queries go to a **trending content index** (updated in near real-time), while stable knowledge queries route to an **evergreen index**. Conversation history from the current session also influences follow-up query reformulation, allowing it to resolve ambiguous references across a multi-turn interaction.[^5][^1]

### Stage 2 — Embedding-Based Indexing

In February 2025, Perplexity released **pplx-embed-v1** and **pplx-embed-context-v1** — custom embedding models in 0.6B and 4B parameter sizes — replacing reliance on third-party providers like OpenAI or Cohere. This means Perplexity owns the complete definition of "relevance" at the most fundamental representation layer. Queries and documents are converted into high-dimensional numerical vectors for semantic similarity matching.[^1]

### Stage 3 — Multi-Method Retrieval

Rather than relying on a single retrieval method, Perplexity runs **three paradigms simultaneously**:[^1]

| Method | Mechanism | Best For |
|--------|-----------|----------|
| **BM25** | Traditional keyword/term matching | Precise term-level queries |
| **Dense Retrieval** | Neural embedding semantic matching | Conceptual, fuzzy, semantic queries |
| **Hybrid** | Combination of both | General-purpose, high-recall retrieval |

A standard Perplexity search retrieves **60+ candidate sources per query**, optimized for breadth and speed. Deep Research reads **hundreds of sources** with significantly greater processing depth. Perplexity has moved from relying on the Bing Web Search API (its 2022 approach) to operating its own **proprietary search infrastructure** indexing hundreds of billions of webpages with tens of thousands of index updates per second.[^1]

### Stage 4 — Multi-Layer ML Ranking (L1–L3)

This is Perplexity's most important quality gate. The ranking pipeline operates across five sequential stages: Intent Mapping → Retrieval → Assessment → Reranking → Final Selection.[^1]

The reranking operates across three ML layers (L1–L3), each applying progressively stricter filters. The system applies a **~0.7 quality threshold** with a critical fail-safe: if no sources meet the quality bar, the system **discards all results and re-queries** rather than serving weak citations. This fail-safe is a significant architectural commitment to source quality — the system explicitly refuses to surface poor sources even if it means returning nothing.[^1]

### Stage 5 — Structured Prompt Assembly

This step has no equivalent in a standard LLM call. **Before the language model is ever invoked**, the system builds a structured prompt containing:[^1]

- Citation markers pre-embedded at specific locations
- Source metadata (URLs, publication dates, domain authority signals)
- Ranked document excerpts, ordered by relevance score

The LLM receives a document-rich context, not an empty question. This is why Perplexity's citations are inline and accurate — the citation numbers are woven into the prompt *before* generation, not added retrospectively.[^1]

### Stage 6 — Constrained LLM Synthesis

The language model generates a prose answer that is **structurally bound by the pre-assembled evidence**. It attaches inline citation numbers to individual claims corresponding to the sources embedded in Stage 5. The model cannot freely confabulate — its generation is anchored to what was retrieved. However, answers exist on a spectrum: some queries will have strong retrieval, others thin retrieval, and the model's parametric knowledge fills gaps when retrieved evidence is sparse.[^1]

***

## Deep Research: The Agentic Multi-Pass Loop

**Deep Research** (launched February 14, 2025) is architecturally distinct from standard search. It operates as an **agentic RAG loop** — the system retrieves, reads, reasons about what information is missing, retrieves again, and iterates across dozens of searches and hundreds of sources. The entire process completes in **2–4 minutes**.[^6][^7][^8][^9][^3][^2][^1]

### The Five-Stage Deep Research Cycle[^7][^8]

```
Stage 1 → QUERY DECOMPOSITION
          Split into sub-questions / research dimensions

Stage 2 → RETRIEVAL PER SUB-QUESTION
          Dedicated search per subtopic (60+ sources each)

Stage 3 → STRUCTURED NOTE-TAKING
          Partial answers written into intermediate notes

Stage 4 → GAP IDENTIFICATION & FOLLOW-UP SEARCH
          Conflicting/missing data triggers additional retrieval loops

Stage 5 → FINAL SYNTHESIS
          Single coherent narrative with inline citations,
          reliability notes, and uncertainty flags
```

The system emulates how a human analyst researches: **asking follow-up questions internally**, refining scope when initial results are insufficient, and ultimately writing a coherent synthesis that merges several independent research threads. Context is preserved between sub-queries to prevent redundant retrieval of already-processed pages.[^7]

Deep Research is powered by a **multi-model routing architecture**: Perplexity's proprietary Sonar models (built on Llama 3.1 70B, optimized for real-time search) handle the retrieval and orchestration layers, while Pro and Max users can select Claude Opus 4.6, GPT-5.2, or Kimi K2.5 Thinking for the synthesis layer. DeepSeek R1 is used specifically for summarization, chain-of-thought reasoning, and rendering.[^10][^1]

***

## The Perplexity Sonar API Model Family

For integration into n8n and agentic pipelines, Perplexity exposes four distinct API models:[^11][^12][^13]

| Model | Context | Speed | Best Use Case | Price (in/out per M tokens) |
|-------|---------|-------|---------------|---------------------------|
| `sonar` | 128K | Fastest | Quick Q&A, summaries, real-time data | $1 / $1 |
| `sonar-pro` | 200K | Moderate | Deep retrieval, complex queries, 2× more sources | $3 / $15 |
| `sonar-reasoning-pro` | 128K | Moderate | Multi-step logic, chain-of-thought, analysis | $2 / $8 |
| `sonar-deep-research` | 128K | Slower | Long-form synthesis, exhaustive report generation | Per use |

On the DeepResearch Bench, `sonar-pro` (high) achieved RACE scores of 38.93 and a FACT citation accuracy of 78.66%, while Perplexity Deep Research led all systems with **90.24% citation accuracy** — the highest precision in source attribution of any tested system.[^14]

### Integrating Perplexity Sonar in n8n

The integration is a simple HTTP Request node targeting Perplexity's OpenAI-compatible `/chat/completions` endpoint:[^15][^16]

```
POST https://api.perplexity.ai/chat/completions
Authorization: Bearer {PERPLEXITY_API_KEY}
Body: {
  "model": "sonar-deep-research",
  "messages": [
    { "role": "system", "content": "You are a research assistant..." },
    { "role": "user", "content": "{{research_query}}" }
  ]
}
```

**Recommended n8n sub-workflow pattern for Perplexity:**

1. `Execute Workflow Trigger` ← receives topic from Orchestrator
2. `Set Node` — compose system role + user query
3. `HTTP Request Node` — POST to Perplexity API with Bearer auth
4. `Code Node` — extract `choices.message.content` + citations array
5. `Return to parent workflow` — structured JSON with content + sources

The workflow acts as the **deep research sub-agent** in the larger multi-agent system, triggered by the Orchestrator when a topic requires cross-source synthesis with automatic citations. The Perplexity Sonar API also has an official OpenAI Agents SDK integration that enables function calling and structured agent interactions on top of Sonar's retrieval.[^16][^17][^15]

### Where Perplexity Fits in the Workflow Hierarchy

```
ORCHESTRATOR (GPT-5.1)
  └─ Decides: "Does this sub-topic need deep web synthesis?"
       YES → calls Perplexity sonar-deep-research sub-workflow
              → returns: full synthesis + 20-50 inline citations
       NO  → routes to Tavily (quick facts) or Firecrawl (page extraction)
```

Perplexity is not a replacement for specialized agents — it is the **"one-shot deep synthesis" tool** for when the orchestrator needs a comprehensive, already-cited answer on a sub-topic without managing the search-retrieve-synthesize cycle manually. Its citation accuracy (90.24%) makes it the most reliable pre-packaged source attribution system available via API.[^14]

***

# Part II: The Real-World Research Process

## Why the Real Process Matters for AI Workflows

The best AI research workflows are not invented from scratch — they are **computerized replications of how skilled human researchers actually work**. Understanding the canonical research process allows the n8n workflow to mirror each phase with the right agents and quality gates, rather than producing outputs that look like research but lack its structural rigor.

The research process is defined as "an organized method of gathering information and answering specific academic and scientific questions" that "acts like an essential guide, from the first step of choosing a topic to writing a comprehensive report". Real workflows are **never linear** — they are iterative cycles nested within a broader cycle. Revision, re-search, and reframing are features, not bugs.[^18][^19]

***

## The Nine Steps of the Real-World Research Process

### Step 1 — Topic Identification & Scoping

Every research project begins with identifying a question, problem, or gap that warrants investigation. Professional researchers ask: *What is already known? What is the gap? Is this question still unanswered?*[^20][^21]

The systematic review protocol at this stage requires: checking for existing reviews on the topic, defining whether a new review is needed, and confirming that the question has not been answered at the required level of rigor elsewhere. Before proceeding, researchers confirm that the scope is neither too narrow (unanswerable) nor too broad (unmanageable).[^22][^23]

**AI workflow equivalent:** The Orchestrator agent's first action — query decomposition and DAG planning — directly mirrors this step. It scopes the query, checks whether sub-topics are well-defined, and identifies what types of sources are needed before dispatching agents.

***

### Step 2 — Literature Review

This is the most foundational step of real research and often the most time-consuming. Its purposes are:[^24][^25][^18]

- **Map the known**: understand what has already been established
- **Identify gaps**: find where conflicting evidence, unexplored angles, or outdated conclusions exist
- **Avoid duplication**: ensure the research adds genuinely new value
- **Inform methodology**: understand which methods work for this type of question

Professional researchers use academic databases (Scopus, Web of Science, PubMed, Google Scholar, JSTOR) and citation tracking. They also consult grey literature — conference proceedings, preprints, technical reports, and government publications — which often contain the most current evidence. **Citation details and source locations are recorded immediately** to enable later verification.[^26][^22][^18]

**AI workflow equivalent:** The Academic Research Agent (Semantic Scholar + ArXiv + OpenAlex) directly operationalizes this step. The key principle to replicate: retrieve broadly, record all sources, and track citation networks — not just the top-ranked results.

***

### Step 3 — Research Question & Hypothesis Formation

Following the literature review, the researcher crystallizes a **specific, testable research question** and forms a hypothesis — a prediction about the relationship between variables. Good research questions are:[^27][^24]

- **Specific** — precisely define what is being investigated
- **Measurable** — can be evaluated against evidence
- **Resolvable** — the answer is findable with the available methods

In systematic reviews, this step uses frameworks like **PICO** (Population, Intervention, Comparison, Outcome) to structure complex multi-dimensional questions. Inclusion and exclusion criteria are defined *before* data collection begins, creating a protocol that reduces confirmation bias.[^28][^22]

**AI workflow equivalent:** The Orchestrator's DAG planning step must encode this structure — each research sub-task should be a precisely scoped question, not a vague topic. Pre-defining what counts as a valid answer (analogous to inclusion/exclusion criteria) prevents agents from drifting into tangentially related material.

***

### Step 4 — Study Design & Methodology Selection

Before collecting data, the researcher selects the appropriate methodology: experimental, observational, qualitative, quantitative, or mixed. This decision determines everything downstream — the validity and generalizability of findings depend on matching the method to the question.[^29][^18]

Professional researchers document their methodology in a **research protocol** before data collection begins. This protocol specifies: data sources, collection methods, analysis procedures, and how conflicting evidence will be resolved. Pre-registration (publishing the protocol before running the study) is the gold standard for reducing publication bias and p-hacking.[^21][^28]

**AI workflow equivalent:** The workflow configuration for each research run — which agents are activated, which sources are included/excluded, what scoring thresholds apply — is the machine equivalent of a research protocol. It should be logged per run for reproducibility.

***

### Step 5 — Data Collection

This step involves gathering primary or secondary data using methods appropriate to the research design. The critical principle is methodical exhaustiveness: the goal is to find **all relevant studies**, not just the easily accessible ones. Professional systematic reviewers:[^28][^18][^20]

- Run searches across multiple databases without language restrictions[^30]
- Approach grey literature (conference papers, reports, patents) systematically
- Collect all retrieved records into a reference manager before any screening[^22]
- Use dual-reviewer screening to reduce selection bias — at least two independent reviewers screen studies and resolve disagreements by consensus[^28]

The quality of data collection directly determines the reliability of findings. Bias in this step — whether from selective databases, language preferences, or recency bias — propagates through the entire analysis.[^18]

**AI workflow equivalent:** The parallel execution of Web Agent + Academic Agent + Social Agent + YouTube Agent at Tier 1 mirrors the principle of multi-source exhaustive collection. The deduplication node, source credibility scoring (Gate 1), and dual-source cross-checking (at least two agents must find a source for high confidence) replicate the dual-reviewer principle.

***

### Step 6 — Data Analysis

Raw collected data is analyzed to identify patterns, test hypotheses, and draw inferences. This step differs fundamentally depending on whether the research is:[^25][^18]

- **Quantitative**: statistical testing (regression, ANOVA, meta-analysis), significance testing, effect size calculation
- **Qualitative**: thematic coding, content analysis, grounded theory
- **Mixed**: triangulation of quantitative and qualitative findings

In systematic reviews, the analysis phase includes a **quality assessment** of each included study using standardized checklists (e.g., PRISMA, Cochrane Risk of Bias). Studies that pass quality thresholds contribute to synthesis; those that fail are excluded from conclusions but documented in the appendix.[^31][^30]

**AI workflow equivalent:** The Synthesizer Agent (Claude 4.5) performs this function — extracting insights, comparing findings across sources, and identifying convergent vs. divergent evidence. The Hallucination Validation Pipeline (Gate 2) is the quality assessment equivalent, filtering claims that lack grounding before they enter the final synthesis.

***

### Step 7 — Synthesis & Interpretation

Synthesis is more than summarization — it is the production of **new insight** by combining multiple independent pieces of evidence. Professional researchers:[^18][^28]

- **Tabulate study characteristics** for comparison
- **Identify heterogeneity** — understand why studies reach different conclusions
- **Weight evidence** by quality and sample size
- **State explicit uncertainty** — good research acknowledges what it cannot conclude

Interpretation requires the researcher to determine whether data **aligns with or refutes the hypothesis**, recognize confounding factors, and be open to unexpected findings. The conclusions must state not only what was found but what the limitations are and what questions remain.[^25]

**AI workflow equivalent:** The Synthesizer Agent + Devil's Advocate Red Team (Gate 3) + LLM-as-Judge (Gate 4) together execute this step. The Red Team agent specifically operationalizes the "be open to unexpected findings" principle — it actively searches for evidence that challenges the initial synthesis, ensuring that the final output is not a confirmation bias artifact.

***

### Step 8 — Peer Review & Verification

Peer review is the **institutional quality gate of the real-world research process**. Before a finding is accepted as scientific knowledge, it must survive scrutiny from independent expert reviewers who evaluate:[^32][^33][^34]

- **Methodology**: Is the design sound? Is the analysis appropriate?
- **Reproducibility**: Can others replicate this?
- **Novelty**: Does it add genuine new knowledge?
- **Bias and ethics**: Are there conflicts of interest? Is the reasoning fair?[^35]

The typical peer review process has 8 stages: Submission → Editorial Assessment → Reviewer Assignment → Peer Review → Decision → Revision & Resubmission → Final Decision → Post-Publication dissemination. Average submission-to-publication time ranges from **5 to 18 months**, with STEM fields generally faster than social sciences. This delay is why preprint servers (ArXiv, bioRxiv, SSRN) have become critical for real-time research access.[^36][^37]

A rigorous peer reviewer evaluates: quality, methodology, potential bias, ethical issues, and reproducibility — and makes a recommendation to Accept, Revise (minor/major), or Reject. Multi-stage open peer review systems add public interactive discussion on top of the traditional closed-reviewer model.[^38][^39][^35]

**AI workflow equivalent:** The Devil's Advocate Agent and LLM-as-Judge perform the peer review function in the automated workflow. The multi-dimensional scoring (completeness, source quality, factual consistency, adversarial survival, citation density) mirrors the multi-axis evaluation of a peer reviewer. The Replan loop (up to 3 iterations when quality gates are not met) mirrors the Revision & Resubmission cycle.

***

### Step 9 — Dissemination & Knowledge Base Integration

The final step of real research is **sharing findings in a form that others can access, verify, and build upon**. This includes:[^21][^28][^18]

- **Writing the report** with full methodological transparency
- **Citing all sources** with complete bibliographic information
- **Acknowledging limitations** explicitly
- **Post-publication engagement**: responding to queries, updating findings as new evidence emerges[^37]

Professional researchers also maintain **reference management systems** (Zotero, Mendeley, Endnote) that store source metadata, PDFs, notes, and citation links in a structured, queryable database. This is the academic equivalent of a vector knowledge base.[^22]

The importance of the distinction between **verified and unverified sources** is paramount: only sources that have survived peer review and methodological scrutiny are cited in the final paper. Grey literature and preprints are used for evidence but flagged as unreviewed.[^30][^22]

**AI workflow equivalent:** The Knowledge Base Exporter is the dissemination agent. The two-database architecture — verified sources in Notion/Qdrant, rejected sources in the audit log — directly mirrors the academic norm of citing only peer-reviewed or scrutinized sources. The run manifest (query, timestamp, agent configs, model versions) is the AI equivalent of a methodology section, enabling reproducibility.

***

## The Full Parallel: Real Research → AI Workflow

| Real Research Step | AI Workflow Equivalent | Agent/Node |
|---|---|---|
| Topic scoping & gap check | Query decomposition + DAG planning | Orchestrator (GPT-5.1) |
| Literature review | Academic search (Semantic Scholar, ArXiv, OpenAlex) | Academic Agent (Gemini 3) |
| Question/hypothesis formation | Sub-question DAG with inclusion/exclusion criteria | Orchestrator prompt engineering |
| Protocol pre-registration | Run manifest logging | Google Sheets / Notion run log |
| Data collection (exhaustive) | Parallel multi-agent retrieval (web, academic, social, YouTube, creator) | Tier-1 agents |
| Dual-reviewer screening | Multi-agent source cross-checking + Gate 1 credibility scoring | Verifier + Credibility Scorer |
| Quality assessment of studies | Hallucination Validation Pipeline | Gate 2 (HVP) |
| Synthesis + heterogeneity analysis | Cross-source synthesis with contradiction flagging | Synthesizer (Claude 4.5) |
| Peer review / adversarial challenge | Red Team Agent + LLM-as-Judge | Gates 3–4 |
| Revision cycle | Replan loop (max 3 iterations) | Orchestrator re-dispatch |
| Publication + reference management | Knowledge Base export (Notion + Qdrant) | KB Exporter sub-workflow |
| Post-publication monitoring | Trusted Creator Monitor (always-on) | Creator Monitor Agent (6h schedule) |

***

## Key Principles from Real Research That AI Workflows Must Preserve

### The Reproducibility Principle

A finding is only scientifically valid if others can reproduce it using the same methods and arrive at the same conclusion. In the AI workflow, this means the run manifest (model versions, agent configs, prompts, source list) must be logged with every research run. The workflow must be deterministic enough that re-running it on the same topic produces a verifiably similar result.[^20][^28]

### The Uncertainty Acknowledgment Principle

Responsible research explicitly states what it cannot conclude. AI-generated synthesis must include **uncertainty flags** — claims with sparse or contradictory evidence should be labeled as uncertain rather than presented with false confidence. The LLM-as-Judge should specifically check for this before approving an output.[^25][^28]

### The Living Review Principle

Research findings are not permanent — they can be overturned by new evidence. This is why the Trusted Creator Monitor (always-on, 6-hour schedule) exists: it continuously scans for new information that may update or invalidate conclusions already in the knowledge base. Each knowledge base entry should have a `last_validated` timestamp and a scheduled re-verification trigger.[^21][^18]

### The Provenance Chain Principle

Every claim in a scientific paper traces back to a primary source — not a summary of a summary. In the AI workflow, this means the source chain must be preserved: the vector store entry for a claim should link to the specific URL, publication, and page from which it was extracted — not just to the agent's synthesized output. This is what makes the knowledge base genuinely usable for citation rather than just for summarization.[^25][^18]

***

## Perplexity Deep Research vs. Traditional Peer-Reviewed Research

A frequent question is whether Perplexity Deep Research can substitute for traditional academic research. The honest answer is: it excels at synthesis and citation but cannot replace primary data collection, experimental methodology, or institutional peer review.

| Dimension | Perplexity Deep Research | Traditional Academic Research |
|-----------|--------------------------|-------------------------------|
| **Speed** | 2–4 minutes[^6] | 5–18 months[^36] |
| **Sources** | Hundreds (web, academic, news) | Systematic review: all meeting inclusion criteria |
| **Factual accuracy** | 93.9% on SimpleQA[^2][^3] | Variable; peer review corrects errors post-publication |
| **Citation accuracy** | 90.24% (highest in class)[^14] | 100% (manual verification required) |
| **Primary data** | Cannot generate — retrieval only | Can generate (experiments, surveys, observations) |
| **Bias protection** | Algorithmic (L1–L3 ranking) | Methodological (protocol + dual-reviewer) |
| **Reproducibility** | Limited — index changes over time | Strong — documented protocol |
| **Uncertainty acknowledgment** | Partial — includes reliability notes[^7] | Explicit — required by journals |
| **Peer review** | None — no independent expert validation | Core — mandatory for publication |

The ideal integration: use Perplexity Deep Research as the **literature review and web synthesis** layer of the AI workflow, then apply the multi-agent verification pipeline (Gates 1–4) to apply the rigor of academic peer review to its outputs before committing anything to the knowledge base.

---

## References

1. [How Perplexity AI Answers Work: Retrieval, Ranking, and Citation ...](https://ziptie.dev/blog/how-perplexity-ai-answers-work/) - Perplexity AI generates cited answers through a multi-stage Retrieval-Augmented Generation (RAG) pip...

2. [How Perplexity AI Ensures Information Accuracy - - WordsAtScale](https://wordsatscale.com/how-does-perplexity-ai-ensure-the-accuracy-of-the-information-it-provides/) - A comprehensive investigative analysis featuring fresh 2025 data, quantitative insights, and actiona...

3. [Perplexity Unveils Deep Research: AI-Powered Tool for ...](https://www.infoq.com/news/2025/02/perplexity-deep-research/) - Perplexity has introduced Deep Research, an AI-powered tool designed for conducting in-depth analysi...

4. [DRACO: a Cross-Domain Benchmark for Deep Research Accuracy ...](https://arxiv.org/html/2602.11685v1)

5. [Perplexity AI Ultimate Guide 2026: Features, Pricing, API, and ...](https://aitoolsdevpro.com/ai-tools/perplexity-guide/) - Learn how to effectively use Perplexity, explore features, prompt examples, and real-world applicati...

6. [Introducing Perplexity Deep Research](https://www.perplexity.ai/hub/blog/introducing-perplexity-deep-research) - Deep Research accelerates question answering by completing in 2-4 minutes what would take a human ex...

7. [Perplexity AI Deep Research: How It Works, Limitations, and Use ...](https://www.datastudios.org/post/perplexity-ai-deep-research-how-it-works-limitations-and-use-cases-for-professionals) - Perplexity AI’s Deep Research mode is the company’s most advanced workflow for generating long-form,...

8. [Perplexity AI Deep Research: How to Get Actually Useful Results](https://masterprompting.net/blog/perplexity-ai-deep-research-prompting) - Standard Perplexity search takes your query, pulls sources, and synthesizes an answer — fast, roughl...

9. [Perplexity Deep Research: AI's New Answer Engine Mode - LinkedIn](https://www.linkedin.com/pulse/what-perplexity-ais-deep-research-mode-dr-hernani-costa-roive) - Discover Perplexity's Deep Research mode that performs dozens of searches in 2-4 minutes, delivering...

10. [We've upgraded Deep Research in Perplexity. It now achieves state ...](https://www.facebook.com/perplexityofficial/posts/weve-upgraded-deep-research-in-perplexityit-now-achieves-state-of-the-art-perfor/1068116903042137/) - With its new Pro AI suite, Perplexity now lets you build full research pipelines, generate live spre...

11. [Perplexity AI Available Models: All Supported Models, Version ...](https://www.datastudios.org/post/perplexity-ai-available-models-all-supported-models-version-differences-capabilities-comparison) - Perplexity AI delivers a diverse model ecosystem for both consumer users and developers, combining a...

12. [Sonar Pro vs Sonar Reasoning Pro - Price Per Token](https://pricepertoken.com/compare/perplexity-sonar-pro-vs-perplexity-sonar-reasoning-pro) - Compare Sonar Pro and Sonar Reasoning Pro API pricing, benchmarks, and capabilities. Sonar Pro costs...

13. [Sonar Pro vs Sonar Reasoning Pro (Comparative Analysis) | Galaxy.ai](https://blog.galaxy.ai/compare/sonar-pro-vs-sonar-reasoning-pro) - In-depth analysis of Sonar Pro vs Sonar Reasoning Pro, revealing performance gaps, cost differences,...

14. [DeepResearch Bench: A Comprehensive Benchmark for Deep Research Agents](https://deepresearch-bench.github.io) - DeepResearch Bench: A Comprehensive Benchmark for Deep Research Agents - Evaluating LLM-based agents...

15. [AI-Powered Research Assistant with Perplexity Sonar API](https://yastime.net/blogs/n8n-workflows/ai-powered-research-assistant-with-perplexity-sonar-api) - Name: AI-Powered Research Agent using Perplexity Sonar Description: This workflow acts as an AI-powe...

16. [AI-powered research assistant with Perplexity Sonar API](https://n8n.io/workflows/3673-ai-powered-research-assistant-with-perplexity-sonar-api/) - Name:AI-Powered Research Agent using Perplexity Sonar Description:This workflow acts as an AI-powere...

17. [OpenAI Agents Integration - Perplexity](https://docs.perplexity.ai/cookbook/articles/openai-agents-integration/README) - Complete guide for integrating Perplexity's Sonar API with the OpenAI Agents SDK

18. [Research Process Steps: Research Procedure and Examples](https://paperpal.com/blog/researcher/research-process-steps-research-procedure-and-examples) - The research process is an organized method of gathering information and answering specific academic...

19. [Research Workflows — VOLT Virtual Online Library Tutorials](https://eps-libraries-berkeley.github.io/volt/Introduction/research_workflows.html)

20. [The Research Process | Steps, How to Start & Tips - ATLAS.ti](https://atlasti.com/research-hub/research-process) - The research process is a systematic method used to gather information and answer specific questions...

21. [Research workflow | FORRT - Framework for Open and ...](https://forrt.org/glossary/english/research_workflow/) - The process of conducting research from conceptualisation to dissemination. A typical workflow may l...

22. [Steps in a Systematic Review - Research Guides - LSU](https://guides.lib.lsu.edu/c.php?g=872965&p=6268540) - A Guide to Conducting Systematic Reviews

23. [Systematic Review Methods - NCBI](https://www.ncbi.nlm.nih.gov/books/NBK44088/) - A systematic review is a protocol driven comprehensive review and synthesis of data focusing on a to...

24. [[Solved] Arrange the following steps of the research process in the c](https://testbook.com/question-answer/arrange-the-following-steps-of-the-research-proces--69aab5e5e39d0f936f2d57a3) - The correct answer is: C → A → B → D The research process in commerce is a systematic sequence of st...

25. [7 steps to the scientific method - www .ec -undp](https://www.ec-undp-electoralassistance.org/_pdfs/textbook-solutions/diQ4gU/7_Steps_To_The_Scientific_Method.pdf)

26. [Realist review protocol for understanding the real-world barriers and enablers to practitioners implementing self-management support to people living with and beyond cancer](https://bmjopen.bmj.com/lookup/doi/10.1136/bmjopen-2020-037636) - Introduction Self-management support can enable and empower people living with and beyond cancer to ...

27. [8.2 – Steps of the Scientific Method - Maricopa Open Digital Press](https://open.maricopa.edu/haasstatistics/chapter/steps-of-the-scientific-method/) - The previous section emphasizes the features of the that make it such an effective tool for research...

28. [What are the Steps of a Systematic Review? - LibGuides](https://hslguides.osu.edu/systematic_reviews/steps) - LibGuides: Systematic Reviews: What are the Steps of a Systematic Review?

29. [The Main Stages of the Research Process](https://www.ijrrjournal.com/IJRR_Vol.10_Issue.7_July2023/IJRR79.pdf)

30. [pmc.ncbi.nlm.nih.gov › articles › PMC539417](https://pmc.ncbi.nlm.nih.gov/articles/PMC539417/)

31. [Beyond the Sensor: A Systematic Review of AI’s Role in Next-Generation Machine Health Monitoring](https://www.mdpi.com/2076-3417/15/19/10494) - This systematic literature review addresses the critical challenge of ensuring robustness and adapta...

32. [How to be a good reviewer: A step‐by‐step guide for approaching peer review of a scientific manuscript](https://pmc.ncbi.nlm.nih.gov/articles/PMC11149763/) - The peer review process is critical to maintaining quality, reliability, novelty, and innovation in ...

33. [Peer review and the publication process](https://pmc.ncbi.nlm.nih.gov/articles/PMC5050543/) - To provide an overview of the peer review process, its various types, selection of peer reviewers, t...

34. [Peer Review in Scientific Publications: Benefits, Critiques, & A ...](https://pmc.ncbi.nlm.nih.gov/articles/PMC4975196/) - Peer review has been defined as a process of subjecting an author’s scholarly work, research or idea...

35. [Understanding the peer-review process | University Libraries](https://library.unr.edu/help/quick-how-tos/evaluating-sources/understanding-the-peer-review-process) - Learn about how the peer-review process works for scholarly articles.

36. [AI-Powered Reforms to End Academic Publishing Delays: A Data-Driven Framework for Faster, Fairer Peer Review](https://www.ssrn.com/abstract=5394931) - Abstract: Academic publishing is facing a timeliness crisis. Despite exponential growth in global re...

37. [Understanding the peer review process: A step-by-step guide for ...](https://www.editage.com/insights/understanding-the-peer-review-process-a-step-by-step-guide-for-researchers) - In this article, we will provide a step-by-step guide to help researchers better understand and navi...

38. [Multi-Stage Open Peer Review: Scientific Evaluation Integrating the Strengths of Traditional Peer Review with the Virtues of Transparency and Self-Regulation](https://www.frontiersin.org/articles/10.3389/fncom.2012.00033/pdf) - ...efficient communication and quality assurance in today’s highly diverse and rapidly evolving worl...

39. [Multi-Stage Open Peer Review: Scientific Evaluation Integrating the Strengths of Traditional Peer Review with the Virtues of Transparency and Self-Regulation](https://pmc.ncbi.nlm.nih.gov/articles/PMC3389610/) - ...efficient communication and quality assurance in today’s highly diverse and rapidly evolving worl...

# n8n Workflow-Spezifikationen

> Technische Specs für alle Sub-Workflows des Research Systems.
> Zielplattform: B-Link R2D2 (lokal, 24/7) — CLI-first Architektur
> Version: 2.0 (Adaptive Pipeline, CLI-first, kein Perplexity)

---

## Übersicht: Sub-Workflow-Hierarchie

```
research-orchestrator (Main Workflow)
  │
  ├─[1] research-phase0-plan
  │
  ├─[2] research-phase1-gather (Parallel-Dispatch)
  │     ├── research-search-kb
  │     ├── research-search-web
  │     ├─��� research-search-deep (Gemini CLI + Search Grounding)
  │     ├── research-search-social (Grok 4 API)
  │     ├── research-search-academic
  │     ├── research-search-youcom (You.com API, optional Deep)
  │     └── research-search-miniflux
  │
  ├─[3] research-phase2-counter
  │
  ├─[4] research-phase3-verify
  │     ├── research-verify-cove
  │     ├── research-verify-factscore
  │     └── research-judge
  │
  ├─[5] research-phase4-synthesize
  │
  ├─[6] research-deliver
  │
  └─[7] research-hitl
```

---

## 1. research-orchestrator (Main Workflow)

### Trigger

| Trigger-Node | Input | Beschreibung |
|---|---|---|
| Webhook (POST `/webhook/research-start`) | `{run_id, query, domain, language, mode, config}` | Portal / OpenClaw / API |
| Schedule Trigger | Pre-konfigurierte Queries | Weekly Digest, Continuous Monitor |
| Manual Trigger | n8n UI Input | Testing |
| Telegram Bot | Natural Language Query | Direkte User-Anfrage |

### Flow

```
Trigger
  │
  ├── SET: run_id generieren (falls nicht vorhanden)
  ├── HTTP Request: SurrealDB — CREATE research_run (status: pending)
  │
  ├── Execute Sub-Workflow: research-phase0-plan
  │     └── Output: search_plan JSON + mode (quick|standard|deep)
  │
  ├── HTTP Request: SurrealDB — UPDATE research_run (status: phase1, search_plan: $plan, mode: $mode)
  │
  ├── Execute Sub-Workflow: research-phase1-gather
  │     └── Output: sources[], claims[]
  │
  ├── IF mode == "standard" OR "deep":
  │     ├── IF: Gate 1 (Standard: ≥8 sources ≥2 platforms, Deep: ≥12 ≥3 ≥5 T1/T2)
  │     │     ├── PASS → Continue
  │     │     └── FAIL → Replan oder HITL
  │     │
  │     ├── IF mode == "deep":
  │     │     ├── Execute Sub-Workflow: research-phase2-counter
  │     │     │     └── Output: counter_evidence[], contradictions[]
  │     │     └── IF: Gate 2 (≥80% claims have counter-research)
  │     │
  │     ├── Execute Sub-Workflow: research-phase3-verify
  │     │     └── Output: verification_table[]
  │     │
  │     └── IF: Gate 3 (Standard: ≥70% verified, Deep: ≥80% + judge ≥3.5)
  │           ├── PASS → Continue
  │           └── FAIL (retries < 3) → Identify weak phase → Replan
  │           └── FAIL (retries ≥ 3) → HITL Escalation
  │
  ├── Execute Sub-Workflow: research-phase4-synthesize
  │     └── Output: report_markdown
  │
  ├── Quality Gate Check (structural)
  │
  ├── IF: Confidence ≥ threshold (Quick: 60%, Standard: 70%, Deep: 80%)
  │     ├── YES → Execute Sub-Workflow: research-deliver
  │     └── NO → Execute Sub-Workflow: research-hitl
  │
  └── HTTP Request: SurrealDB — UPDATE research_run (status: completed)
```

### Error Handling
- Jeder Execute Sub-Workflow Node hat Error Branch
- Error → Log to SurrealDB + Telegram Notification
- Circuit Breaker: 3 consecutive failures → 15min cooldown

---

## 2. research-phase0-plan

### Input
```json
{
  "query": "string — natürliche Sprache",
  "domain": "string — auto-classified oder override",
  "language": "string — de|en",
  "mode": "string — standard|weekly_digest|product_comparison|..."
}
```

### Nodes
1. **Execute Command** — Codex CLI für Query Analysis + Decomposition + Modus-Klassifizierung
   ```bash
   codex exec "Analysiere diese Forschungsfrage und liefere ein JSON mit:
   1. sub_questions (array)
   2. search_terms (primary_de, primary_en, counter_de, counter_en)
   3. sources (welche Branches relevant sind)
   4. scope (time_range, languages, exclusion_criteria)
   5. domain_classification
   6. mode (quick|standard|deep) basierend auf Komplexität

   Query: {{query}}

   Regeln für Modus:
   - quick: Einfache Fakten, kurze Antworten, eine Perspektive reicht
   - standard: Vergleiche, Analysen, multiple Perspektiven nötig
   - deep: Investitionsentscheidungen, Tech-Evaluierungen, hohe Konsequenz

   Antwort NUR als JSON."
   ```

2. **Code Node** — JSON parsen + Modus-Override prüfen (User kann `[deep]` im Query angeben)
3. **Execute Command** — KB-Check: Haben wir schon etwas zu diesem Thema?
   - `python3 ~/.openclaw/workspace/scripts/kb-search.py "{{query}}"` (minimal, nur Existenz-Check)

### Output
```json
{
  "search_plan": { ... },
  "kb_existing": true|false,
  "kb_hits_count": 0
}
```

---

## 3. research-phase1-gather

### Input
`search_plan` JSON aus Phase 0

### Nodes (PARALLEL via n8n Split-Merge)

```
search_plan
  │
  ├── Branch A: research-search-kb ─────────────────┐
  ├── Branch B: research-search-web ────────────────┤
  ├── Branch C: research-search-deep (Gemini CLI) ──┤
  ├── Branch D: research-search-social (Grok API) ──┤── Merge Node
  ├── Branch E: research-search-academic ───────────┤
  ├── Branch F: research-search-miniflux ───────────┤
  └── Branch G: research-search-youcom (optional) ──┘
        │
        ▼
  Deduplication (Code Node: URL-basiert)
        │
        ▼
  Source Credibility Scoring (Gate 1)
        │
        ▼
  Claim Extraction (AI Agent)
```

### Output
```json
{
  "sources": [
    {
      "url": "string",
      "title": "string",
      "date": "ISO datetime",
      "platform": "web|academic|social|youtube|rss|kb",
      "tier": "T1|T2|T3",
      "relevance_score": 0.85,
      "credibility_score": 72,
      "creator_trusted": false,
      "content_summary": "string (500 chars max)",
      "raw_content": "string (full text)"
    }
  ],
  "claims": [
    {
      "id": "c-1",
      "text": "string",
      "source_urls": ["..."],
      "confidence": 0.7
    }
  ],
  "gate1_passed": true,
  "stats": {
    "total_sources": 15,
    "unique_platforms": 4,
    "t1_t2_sources": 8
  }
}
```

---

## 4. Sub-Workflow: research-search-web

### Nodes
1. **HTTP Request** — Brave Search API
   - `GET https://api.search.brave.com/res/v1/web/search?q={{search_terms}}`
   - Header: `X-Subscription-Token: {{BRAVE_API_KEY}}`

2. **HTTP Request** — Tavily Search (parallel mit Brave)
   - `POST https://api.tavily.com/search`
   - Body: `{"query": "{{search_terms}}", "search_depth": "advanced", "max_results": 10}`

3. **Code Node** — Merge + Deduplicate (URL-basiert)

4. **HTTP Request** — Tavily Extract (Top 5 URLs)
   - `POST https://api.tavily.com/extract`
   - Body: `{"urls": ["..."]}`

### Output
Array von Source-Objekten mit URL, Titel, Content, Datum.

---

## 5. Sub-Workflow: research-search-deep (Gemini CLI + Search Grounding)

Ersetzt Perplexity Sonar — nutzt Gemini CLI mit nativem Google Search Grounding (5K free/Mo).

### Nodes
1. **Execute Command** — Gemini CLI mit Search Grounding
   ```bash
   gemini -p "Recherchiere umfassend mit Web-Quellen zum Thema: {{research_query}}.
   Gib für jede Aussage die Quellen-URL an.
   Format: Strukturierte Analyse mit nummerierten Quellen am Ende.
   Sprache: {{language}}" --sandbox
   ```

2. **Code Node** — Output parsen: Synthese-Text + URLs extrahieren

### Output
Synthesis-Text + Array von zitierten URLs (aus Google Search Grounding).

### Modus
Standard + Deep (nicht für Quick — dort reicht Branch B).

---

## 5b. Sub-Workflow: research-search-youcom (You.com Research API — optional)

Nur im Deep-Modus. #1 auf DeepSearchQA Benchmark. $100 Free Credit.

### Nodes
1. **HTTP Request** — You.com Research API
   ```
   GET https://api.ydc-index.io/research
     ?query={{research_query}}
   Authorization: Bearer {{YOUCOM_API_KEY}}
   ```

2. **Code Node** — Extract answer + citations

### Output
Research-Synthese mit zitierten URLs.

---

## 6. Sub-Workflow: research-search-miniflux

### Nodes
1. **HTTP Request** — MiniFlux Search
   ```
   GET http://localhost:8070/v1/entries
     ?search={{keywords}}
     &status=unread
     &limit=50
     &order=published_at
     &direction=desc
   Authorization: {{MINIFLUX_API_KEY}}
   ```

2. **Code Node** — Filter nach Relevanz + Domain-Matching
3. **Code Node** — Content-Extraktion aus Entry-Feldern

### Output
Array von RSS-Einträgen mit Content, URL, Feed-Name, Datum. Auto-T2 Trust.

---

## 7. Sub-Workflow: research-search-academic

### Nodes
1. **HTTP Request** — Semantic Scholar
   ```
   GET https://api.semanticscholar.org/graph/v1/paper/search
     ?query={{search_terms}}
     &limit=20
     &fields=title,abstract,url,citationCount,year,authors
   ```

2. **HTTP Request** — ArXiv (parallel)
   ```
   GET http://export.arxiv.org/api/query
     ?search_query=all:{{search_terms}}
     &max_results=20
     &sortBy=relevance
   ```

3. **Code Node** — Merge + Dedup (nach DOI/Titel)
4. **Code Node** — Relevanz-Scoring (Citation Count, Recency, Keyword Match)

### Output
Array von Paper-Objekten mit Titel, Abstract, URL, Autoren, Citations, Jahr.

---

## 8. Sub-Workflow: research-search-social

### Nodes
1. **xAI Grok Chat Model** Node (native n8n)
   - Model: Grok 4
   - System: "Search X/Twitter for recent discussions, opinions, and trends about: {{topic}}"
   - `search_parameters: {mode: "auto"}` für DeepSearch

2. **Code Node** — Structured Extraction (Posts, Sentiment, Key Opinions)

### Output
Array von Social-Posts mit Author, Content, Engagement, Sentiment-Score.

---

## 9. YouTube-Integration (via Gemini CLI in Branch C)

YouTube wird nicht als eigener Branch implementiert, sondern über Branch C (Gemini CLI) abgedeckt.
Bei Bedarf kann `yt-transcript.py` in einem Code Node aufgerufen werden:

```bash
python3 ~/.openclaw/workspace/scripts/yt-transcript.py "{{video_url}}"
```

Die Gemini CLI mit Search Grounding findet automatisch YouTube-Inhalte als Teil der Google-Suche.

---

## 10. research-phase2-counter

### Input
Claims aus Phase 1

### Nodes
1. **Loop Over Items** — Für jede Kernaussage (max 15):

   a. **HTTP Request** — Counter-Search (Brave/Tavily mit negated Terms)
      - `"{{claim}} Probleme Kritik scheitert Nachteile"`

   b. **Execute Command** — Claude CLI (Opus) — Devil's Advocate
      ```bash
      claude -p "Du bist ein kritischer Analyst. Generiere die 5 stärksten Gegenargumente zu: {{claim}}" --model opus
      ```

   c. **Execute Command** — Claude CLI (Opus) — Pre-Mortem
      ```bash
      claude -p "Wenn diese Empfehlung in 6 Monaten falsch ist — warum? Claim: {{claim}}" --model opus
      ```

2. **Code Node** — Widersprüche identifizieren (Source A sagt X, Source B sagt Y)

### Output
```json
{
  "counter_evidence": [...],
  "devils_advocate": { "arguments": [...], "pre_mortem": "..." },
  "contradictions": [
    { "sourceA": "...", "claimA": "...", "sourceB": "...", "claimB": "...", "resolution": null }
  ]
}
```

---

## 11. research-phase3-verify

### Nodes (Sub-Workflows, teilweise parallel)

1. **Execute Sub-Workflow: research-verify-cove**
   - Code Node: `python3 research-quality-gate.py --cove --claims '{{claims_json}}'`
   - Factored CoVe: Verifikationsfragen ISOLIERT beantworten (kein Report-Kontext)

2. **Execute Sub-Workflow: research-verify-factscore** (Sprint 3)
   - Code Node: `python3 research-quality-gate.py --factscore --claims '{{claims_json}}'`
   - Atomare Claims gegen Web-Suche prüfen

3. **Execute Sub-Workflow: research-judge**
   - Execute Command: Gemini CLI — Cross-Model Judge
   ```bash
   gemini -p "Bewerte diesen Research-Report auf 5 Dimensionen (Score 1-5 pro Dimension):
   1. Relevance 2. Accuracy 3. Completeness 4. Bias 5. Actionability
   Report: {{report_summary}}" --sandbox
   ```
   - 5 Dimensionen: Relevance, Accuracy, Completeness, Bias, Actionability
   - Score 1-5 pro Dimension

4. **Code Node** — Verification Table zusammenbauen

### Output
```json
{
  "verification_table": [
    {
      "claim_id": "c-1",
      "text": "...",
      "cove_status": "verified|partially|failed",
      "factscore_status": "SUPPORTED|NOT_SUPPORTED|AMBIGUOUS",
      "judge_score": 4.2,
      "final_status": "verified|partially_verified|refuted|ambiguous",
      "confidence": 0.92
    }
  ],
  "overall": {
    "verified_pct": 85,
    "judge_avg": 4.1,
    "gate3_passed": true
  }
}
```

---

## 12. research-phase4-synthesize

### Nodes
1. **Code Node** — Freshness Check
   - Versionen, Preise, Modellnamen: Aktuell?
   - >12 Monate alte Quellen: `[Stand: YYYY-MM]` markieren

2. **Execute Command** — CLI-basierte Report-Synthese
   - Quick/Standard: Gemini CLI
   - Deep: Claude CLI (Opus) für höchste Qualität
   ```bash
   # Standard:
   gemini -p "Erstelle einen Research-Report nach Template v3: {{verified_data}}" --sandbox
   # Deep:
   claude -p "Erstelle einen Research-Report nach Template v3: {{verified_data}}" --model opus
   ```
   - Template v3: Executive Verdict, PRISMA, Decision Table, Detailanalyse, Gegenrecherche, Widersprüche, Verification Table, Next Action, Open Risks, Quellen
   - Sprache: `{{language}}` (de oder en)

3. **Code Node** — Template v3 Compliance Check
   - Alle Pflicht-Sektionen vorhanden?
   - Claim Verification Table vorhanden?
   - PRISMA Protocol vollständig?

### Output
```json
{
  "report_markdown": "# Research Report ...",
  "title": "...",
  "verdict": "ADOPT|TEST|REJECT",
  "quality_score": 0.87,
  "template_compliant": true
}
```

---

## 13. research-deliver

**Wichtig:** Verwendet den **Research Bot** (dedizierter Telegram Bot, NICHT Nathan Bot).

### Nodes (parallel)
1. **Telegram (Research Bot)** — Report-Summary + Link an Nico (Chat-ID: 827301846)
   - Bot Token: In n8n als "Research Bot" Credential konfiguriert
   - Format: Markdown mit Executive Verdict + Top 3 Findings + Quellen-Count
2. **Google Drive** — Upload Markdown + optional PDF in `Familie/Research/`
3. **HTTP Request** — SurrealDB KB-Writeback
   - INSERT research_report
   - INSERT/UPDATE source_registry (Reputation-Update)
   - INSERT used_source (pro Run)
   - INSERT research_claim (pro Claim)
   - UPDATE research_run SET status = 'completed'
   - Verified Claims (≥T2) → openclaw/knowledge (Sync)
4. **HTTP Request** — OpenClaw Webhook Callback (falls trigger_source = 'openclaw')

---

## 14. research-hitl

**Verwendet den Research Bot** — HITL-Buttons kommen vom Research Bot, kein Konflikt mit Nathan Bot.

### Nodes
1. **Telegram (Research Bot)** — Inline Buttons senden an Nico (827301846)
   - `[✅ Approve] [❌ Reject] [✏️ Edit Query]`
   - Attachment: Report-Preview (erste 500 Zeichen)
   - Bot Token: "Research Bot" Credential

2. **Wait** — Warte auf Telegram Callback Query (Timeout: 24h)

3. **Switch** — Basierend auf Button-Antwort:
   - Approve → Weiter zu research-deliver
   - Reject → SurrealDB UPDATE status = 'failed', reason = 'user_rejected'
   - Edit Query → Zurück zu Phase 0 mit neuem Query

---

## 15. Credentials & CLIs

### CLIs (lokal auf B-Link, Auth bereits konfiguriert)

| CLI | Verwendet in | Aufruf |
|---|---|---|
| `codex` | Phase 0 (Planning) | `codex exec "..."` |
| `gemini` | Phase 1 (Deep), Phase 3 (Judge), Phase 4 (Standard) | `gemini -p "..." --sandbox` |
| `claude` | Phase 2 (Devil's Advocate), Phase 4 (Deep) | `claude -p "..." --model opus` |

### API Keys (in n8n konfiguriert)

| Credential | Typ | Verwendet in |
|---|---|---|
| Brave Search API | API Key | research-search-web |
| Tavily API | API Key | research-search-web |
| xAI/Grok API | API Key | research-search-social |
| You.com API | API Key | research-search-youcom (optional) |
| SurrealDB | HTTP Basic Auth | Alle Status-Updates |
| MiniFlux | API Key | research-search-miniflux |
| Research Bot (Telegram) | Bot Token | research-deliver, research-hitl |
| Google Drive | OAuth | research-deliver |

---

## 16. Bestehende Scripts → n8n Code Nodes

| Script | n8n-Verwendung | Aufruf |
|---|---|---|
| `research.py` | Nicht direkt — Logik in einzelne Sub-Workflows aufgeteilt | — |
| `research-quality-gate.py` | Phase 3 (CoVe, FActScore, Judge) | `python3 research-quality-gate.py --cove\|--factscore\|--judge` |
| `yt-transcript.py` | Phase 1 YouTube Branch | `python3 yt-transcript.py "{{url}}"` |
| `kb-search.py` | Phase 0 (Existenz-Check) + Phase 1 (KB-Branch) | `python3 kb-search.py "{{query}}"` |
| `kb-ingest.py` | Delivery Phase (KB-Writeback) | Via SurrealDB direkt (HTTP Request) |

---

## 17. OpenClaw Skill: `research-workflow`

Neuer Skill in `~/.openclaw/skills/research-workflow/SKILL.md`, damit Nathan den n8n Research-Workflow triggern kann.

### Trigger
Nathan erkennt Research-Anfragen ("recherchiere X", "untersuche Y", "analysiere Z") und nutzt den Skill statt Spock zu spawnen.

### Aktion
```bash
curl -X POST http://localhost:5678/webhook/research-start \
  -H "Content-Type: application/json" \
  -d '{
    "query": "{{research_query}}",
    "domain_hint": "{{domain_or_auto}}",
    "language": "{{detected_language}}",
    "trigger_source": "openclaw",
    "requester": "nico",
    "chat_id": 827301846
  }'
```

### Antwort an Nico
"Research-Auftrag gestartet. Der Report kommt über den Research Bot, sobald er fertig ist."

### Nathan SOUL.md Änderung
```diff
- Nathan recherchiert NICHT selbst. Research-Tasks → IMMER Spock spawnen.
+ Nathan recherchiert NICHT selbst. Research-Tasks → research-workflow Skill triggern (n8n).
+ Spock wird nur noch für Echtzeit-Fragen im Konversationskontext verwendet.
```

**Prinzip:** n8n orchestriert, Scripts machen die Arbeit. Kein Rewrite from scratch.
